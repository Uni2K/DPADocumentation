package com.project.app.Helpers

import android.os.Bundle
import android.support.v7.util.DiffUtil
import android.util.Log
import com.project.app.Objects.Question


class DiffUtilCallback(val newList: ArrayList<Question>, val oldList: ArrayList<Question>) : DiffUtil.Callback() {
    override fun areItemsTheSame(p0: Int, p1: Int): Boolean {
        //IDS are the same
        val result = newList[p1].compareTo(oldList[p0])
        return result != 0
    }

    override fun getOldListSize(): Int {
        return oldList.size
    }

    override fun getNewListSize(): Int {

        return newList.size

    }

    override fun areContentsTheSame(p0: Int, p1: Int): Boolean {
        val result = newList[p1].compareTo(oldList[p0])
        return !(result != 10 && result != 0)
    }

    override fun getChangePayload(oldItemPosition: Int, newItemPosition: Int): Any? {
        val questionOld = oldList[oldItemPosition]
        val questionNew = newList[newItemPosition]
        val diff = Bundle()


        if (questionNew.text != questionOld.text) {
            diff.putString("text", questionNew.text)
        }
        if (questionNew.enabled != questionOld.enabled) {
            diff.putBoolean("done", questionNew.enabled)

        }
        if (!(questionNew.answers contentEquals questionOld.answers)) {
            diff.putStringArray("answers", questionNew.answers)
        }

        if (!(questionNew.votes contentEquals questionOld.votes)) {
            diff.putIntArray("votes", questionNew.votes.toIntArray())

        }

        if (questionNew.userid != questionOld.userid) {
            diff.putString("userid", questionNew.userid)
        }

        if (questionNew.timestamp != questionOld.timestamp) {
            diff.putString("timestamp", questionNew.timestamp)
        }

        Log.e("changePayload", "PAYLOAD" +diff.size()+"  "+questionNew.votes[0])
        if (diff.size() == 0) {
            return null
        }
        return diff
    }


}

