package com.project.app.Fragments

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.project.app.Interfaces.AdditionalScreenInterface
import com.project.app.R

class StartupFragment: Fragment() {
    lateinit var callback: AdditionalScreenInterface

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        var view=inflater.inflate(R.layout.fragment_startup, null)
        callback.onClose()
        view.setOnClickListener {
            callback.onClose()
        }
        return view
    }
    fun setOnHeadlineSelectedListener(callback: AdditionalScreenInterface) {
        this.callback = callback
    }
}