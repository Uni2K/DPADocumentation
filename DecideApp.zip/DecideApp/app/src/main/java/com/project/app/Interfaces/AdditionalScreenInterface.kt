package com.project.app.Interfaces

interface AdditionalScreenInterface {
    fun onClose()
}