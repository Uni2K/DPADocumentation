package com.project.app.Adapters

import android.content.res.ColorStateList
import android.graphics.Color
import android.opengl.Visibility
import android.support.constraint.ConstraintLayout
import android.support.v4.content.ContextCompat
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.project.app.Fragments.QuestionCreateDialogFragment
import com.project.app.Fragments.TagFragment
import com.project.app.Objects.Tag
import com.project.app.R


class TagAdapter(var content: List<Tag>, val parent:TagFragment) : RecyclerView.Adapter<TagAdapter.ViewHolder>() {
    var mRecyclerView: RecyclerView? = null
    companion object {
        val FAV_CONST="-222"
    }


    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        mRecyclerView = recyclerView
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): ViewHolder {
        val inflatedView = LayoutInflater.from(p0.context).inflate(R.layout.adapter_tag, p0, false)


        return ViewHolder(inflatedView)
    }

    override fun getItemCount(): Int {
        return content.size+1
    }


    override fun getItemViewType(position: Int): Int {
        if(position==0){
            return 1
        }
        return 0
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {


        when(viewHolder.itemViewType){
            0->{
                var c=position-1
                viewHolder.name.text=content[c].name
                viewHolder.c2.setBackgroundColor(Color.parseColor(content[c].color))
                viewHolder.c1.setColorFilter(Color.parseColor(content[c].color), android.graphics.PorterDuff.Mode.SRC_IN)
                viewHolder.heart.visibility=View.GONE
                viewHolder.itemView.backgroundTintList= null

                viewHolder.itemView.setOnClickListener {

                    parent.setSubTag(content[c])


                }
            }
            1->{
                viewHolder.name.text="Favorites"
                val colo=viewHolder.itemView.resources.getColor(R.color.favoriteColor,null)
                val colo_b=viewHolder.itemView.resources.getColor(R.color.favoriteColorBackground,null)
                viewHolder.c2.setBackgroundColor(colo)
                viewHolder.c1.setColorFilter(colo, android.graphics.PorterDuff.Mode.SRC_IN)
                viewHolder.heart.visibility=View.VISIBLE
                viewHolder.heart.setImageResource(R.drawable.baseline_favorite_24)
                viewHolder.itemView.backgroundTintList= ColorStateList.valueOf( colo_b)

                viewHolder.itemView.setOnClickListener {

                    parent.setSubTag(Tag(FAV_CONST,"",true,"",""))


                }
            }
        }







    }



    class ViewHolder(v: View) : RecyclerView.ViewHolder(v), View.OnClickListener {
        val name:TextView=v.findViewById(R.id.tag_name)
        val parent:ConstraintLayout=v.findViewById(R.id.tag_parent)
        val c1:ImageView=v.findViewById(R.id.tag_c1)
        val c2:View=v.findViewById(R.id.tag_c2)
        val heart: ImageView =v.findViewById(R.id.tag_heart)

        init {
        }

        override fun onClick(v: View) {
        }

    }
}