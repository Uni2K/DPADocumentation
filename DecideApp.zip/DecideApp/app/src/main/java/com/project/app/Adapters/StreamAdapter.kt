package com.project.app.Adapters

import android.content.Context
import android.content.res.ColorStateList
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.project.app.Fragments.QuestionSwitchFragment
import com.project.app.Objects.Question
import com.project.app.R
import android.os.Bundle
import android.support.v7.util.DiffUtil
import android.support.v7.widget.LinearLayoutManager
import com.project.app.Helpers.DiffUtilCallback
import com.project.app.Helpers.DiffUtilVoteCallback
import com.project.app.Helpers.LocalBase
import com.project.app.Interfaces.QuestionChangeListener
import com.project.app.Interfaces.UpdateListener
import com.project.app.Interfaces.VoteInterface
import com.project.app.Objects.Update
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.*
import kotlin.collections.ArrayList
import android.support.v4.graphics.drawable.DrawableCompat
import android.graphics.drawable.Drawable
import android.support.annotation.ColorInt




class StreamAdapter(private val content: ArrayList<Question>, val context: Context) :
    RecyclerView.Adapter<StreamAdapter.ViewHolder>() {
    var mRecyclerView: RecyclerView? = null
    lateinit var localBase: LocalBase

    init {
        if (!::localBase.isInitialized) {
            localBase = LocalBase(context)
        }
    }

    private val pendingUpdates: Queue<ArrayList<Question>> = ArrayDeque()
    private val pendingVoteUpdates: Queue<Update> = ArrayDeque()

    lateinit var questionSwitchFragment: QuestionSwitchFragment

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        mRecyclerView = recyclerView
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): ViewHolder {
        val inflatedView = LayoutInflater.from(p0.context).inflate(R.layout.question_view_medium, p0, false)


        return ViewHolder(inflatedView)
    }

    override fun getItemCount(): Int {
        return content.size
    }


    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int, payloads: MutableList<Any>) {
        if (payloads.isEmpty()) {
            super.onBindViewHolder(viewHolder, position, payloads)
        } else {


            val o: Bundle = payloads[0] as Bundle
            for (key: String in o.keySet()) {
                Log.e("DISPATCH RESULTS: ", "LOAD" + key)

                when (key) {
                    "text" -> {
                        viewHolder.medium_text.text = content[position].text
                    }
                    "votes" -> {
                        setVotes(viewHolder, content[position])
                    }
                    "votesReceived" -> {
                        setUserVote(viewHolder, o[key])

                    }
                }

            }
        }


    }

    private fun setUserVote(viewHolder: ViewHolder, payload: Any?) {
        Log.d("setUSERVOTE", "STREAMDADAPTER")





        when (payload.toString().toInt()) {
            0 -> {
                viewHolder.medium_answerleft.setBackgroundResource(R.drawable.button_decider_a1)
                viewHolder.medium_answerright.setBackgroundResource(R.drawable.button_decider)
            }
            1 -> {
                viewHolder.medium_answerright.setBackgroundResource(R.drawable.button_decider_a2)
                viewHolder.medium_answerleft.setBackgroundResource(R.drawable.button_decider)
            }
        }

    }

    fun setVotes(viewHolder: ViewHolder, qst: Question) {
        val allvotes=qst.votes[0] + qst.votes[1]
        viewHolder.medium_addfield2.text = allvotes.toString()
        viewHolder.medium_addfield1.text = (Math.round((qst.votes[0].toFloat()/allvotes)*100f)).toString()+"%"
        viewHolder.medium_addfield3.text = (Math.round((qst.votes[1].toFloat()/allvotes)*100f)).toString()+"%"


    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        var qst: Question = content[position]
        // questionSwitchFragment.listenForUpdates()
        viewHolder.medium_text.text = qst.text
        viewHolder.medium_answerleft.text = qst.answers[0]
        viewHolder.medium_answerright.text = qst.answers[1]
        if(qst.context.length==0){
            viewHolder.medium_context.visibility=View.GONE
        }else{
            viewHolder.medium_context.visibility=View.VISIBLE

        }
        viewHolder.medium_context.text = qst.context

        viewHolder.medium_recycler.adapter = TagOverviewAdapter(ArrayList(qst.tags.toList()))
        viewHolder.medium_recycler.layoutManager =
            LinearLayoutManager(viewHolder.medium_addfield1.context, LinearLayoutManager.HORIZONTAL, false)
        viewHolder.medium_recycler.setHasFixedSize(false)
        setVotes(viewHolder, qst)


        viewHolder.medium_answerleft.setOnClickListener {
            if (localBase.getVote(qst._id) == null)
                questionSwitchFragment.questionAnswered(0, qst)
        }
        viewHolder.medium_answerright.setOnClickListener {
            if (localBase.getVote(qst._id) == null)
                questionSwitchFragment.questionAnswered(1, qst)
        }
        viewHolder.medium_clicker.setOnClickListener {


            if (::questionSwitchFragment.isInitialized) {
                questionSwitchFragment.showFullView(content[position])
            }
        }

        val update = localBase.getVote(qst._id)
        if (update != null) {
            Log.d("StreamAdapter", "VOTE FOUND FOR: " + qst._id)
            setUserVote(viewHolder, update.voteon)
        }

    }

    private fun applyDiffResult(newItems: ArrayList<Question>, diffResult: DiffUtil.DiffResult) {
        pendingUpdates.remove()
        dispatchUpdates(newItems, diffResult)
        if (pendingUpdates.size > 0) {
            updateItemsInternal(pendingUpdates.peek())
        }
    }

    private fun applyDiffResultVotes(newItems: ArrayList<Question>, diffResult: DiffUtil.DiffResult) {
        pendingVoteUpdates.remove()
        dispatchUpdates(newItems, diffResult,false)
        if (pendingVoteUpdates.size > 0) {
            updateVotesInternal(pendingVoteUpdates.peek())
        }
    }

    private fun dispatchUpdates(newItems: ArrayList<Question>, diffResult: DiffUtil.DiffResult, clear: Boolean = true) {
        Log.e("DISPATCH RESULTS:222 ", "RESULTS:")

        GlobalScope.launch(Dispatchers.Main) {
            diffResult.dispatchUpdatesTo(this@StreamAdapter)
            if (clear) {
                content.clear()
                content.addAll(newItems)
            }
        }

    }

    /**
     *Process the diff on a background thread
    Return to the main thread
    Update the backing data
    Notify the adapter of the changes.
     */
    fun updateItems(newItems: ArrayList<Question>) {


        pendingUpdates.add(newItems);
        if (pendingUpdates.size > 1) {
            return
        }
        updateItemsInternal(newItems)
    }

    fun updateVote(update: Update) {

        pendingVoteUpdates.add(update)
        if (pendingVoteUpdates.size > 1) {
            return
        }
        updateVotesInternal(update)
    }

    override fun onViewDetachedFromWindow(holder: ViewHolder) {
        questionSwitchFragment.removeUpdatesFromQuestion(content[holder.adapterPosition])
        super.onViewDetachedFromWindow(holder)
    }

    override fun onViewAttachedToWindow(holder: ViewHolder) {
        questionSwitchFragment.addUpdatesToQuestion(content[holder.adapterPosition], object : QuestionChangeListener {
            override fun onUpdate(timestamp: String, newData: List<Question>) {
                Log.e("ONUPDATE","STREAMADAPTER")
                updateItems(ArrayList(newData))
            }

            override fun onError(er: String) {
            }
        }, object: UpdateListener{
            //When user voted for
            override fun onUpdatesReady(content: ArrayList<Update>, timest: Long) {
                if(content[0].userid==questionSwitchFragment.activity.getSocketBase().generateUserID()) {
                    updateVote(content[0])
                    localBase.addVote(content[0])
                }
            }

            override fun onFailed() {
            }
        })


        if (localBase.getVote(content[holder.adapterPosition]._id) == null) {
            questionSwitchFragment.getVotesForUser(content[holder.adapterPosition], object : VoteInterface {
                override fun onVotesReceived(args: Update) {
                    updateVote(args)
                    localBase.addVote(args)
                }
            })
        }

        super.onViewAttachedToWindow(holder)
    }

    fun updateVotesInternal(update: Update) {
        GlobalScope.launch {


            val diffResult = DiffUtil.calculateDiff(DiffUtilVoteCallback(content, update))

            withContext(Dispatchers.Main) {
                applyDiffResultVotes(content, diffResult)
            }

        }


    }

    fun updateItemsInternal(newData: ArrayList<Question>) {
        GlobalScope.launch {
            var arrayList: ArrayList<Question> = ArrayList(content)
            var addNew: ArrayList<Question> = ArrayList()
            for (nq in newData) {

                var alreadyHere = false
                for (q in content) {
                    if (nq._id == q._id) {
                        alreadyHere = true
                        arrayList[arrayList.indexOf(q)] = nq
                        Log.e(
                            "Update Quesiot NUMMER: ",
                            "ID: " + nq._id + "  NEW: " + q.text + "   OLD: " + q._id + "   " + q.text
                        )
                        break
                    }
                }
                if (!alreadyHere) {
                    Log.e("ADD Quesiot NUMMER: ", "ID: " + nq._id + "  NEW: " + nq.votes[0] + "   OLD: " + nq.votes[0])

                    addNew.add(nq)
                }

            }
            Log.e("DATA: ", "DD: " + arrayList.size + "  " + newData.size + "  " + content.size)

            for (new in addNew) {
                arrayList.add(0, new)
            }


            val diffResult = DiffUtil.calculateDiff(DiffUtilCallback(arrayList, content))

            withContext(Dispatchers.Main) {
                applyDiffResult(arrayList, diffResult)
            }

        }


    }


    fun connectFragment(questionSwitchFragment: QuestionSwitchFragment) {
        this.questionSwitchFragment = questionSwitchFragment
    }


    class ViewHolder(v: View) : RecyclerView.ViewHolder(v), View.OnClickListener {

        val medium_text: TextView = v.findViewById(R.id.medium_question)
        val medium_answerleft: TextView = v.findViewById(R.id.medium_left)
        val medium_answerright: TextView = v.findViewById(R.id.medium_right)
        val medium_context: TextView = v.findViewById(R.id.medium_context)
        val medium_addfield1: TextView = v.findViewById(R.id.medium_text1)
        val medium_addfield2: TextView = v.findViewById(R.id.medium_text2)
        val medium_addfield3: TextView = v.findViewById(R.id.medium_text3)
        val medium_recycler: RecyclerView = v.findViewById(R.id.recycler_tags)
        val medium_clicker:View=v.findViewById(R.id.clicker)

        init {
        }

        override fun onClick(v: View) {
        }

    }
}