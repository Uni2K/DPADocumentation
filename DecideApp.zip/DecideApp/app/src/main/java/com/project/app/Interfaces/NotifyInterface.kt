package com.project.app.Interfaces

interface NotifyInterface {
    fun onNewCount(count:Int, timestamp:String)
}