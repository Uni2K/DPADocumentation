package com.project.app.Adapters

import android.content.res.ColorStateList
import android.graphics.Color
import android.support.v4.content.ContextCompat
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.project.app.Fragments.QuestionCreateDialogFragment
import com.project.app.Objects.Tag
import com.project.app.R


class TagOverviewAdapter(val content:ArrayList<Tag> = ArrayList(), val isBig:Boolean=false) : RecyclerView.Adapter<TagOverviewAdapter.ViewHolder>() {
    var mRecyclerView: RecyclerView? = null
  //  var content: ArrayList<SubTag> = ArrayList()



    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        mRecyclerView = recyclerView
    }

    override fun getItemViewType(position: Int): Int {

        if(isBig)return 1
        return 0

    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): ViewHolder {

        when(p1){
            0->{
                val inflatedView = LayoutInflater.from(p0.context).inflate(R.layout.adapter_tagoverview, p0, false)


                return ViewHolder(inflatedView)
            }
            1->{
                val inflatedView = LayoutInflater.from(p0.context).inflate(R.layout.adapter_tagoverview_big, p0, false)


                return ViewHolder(inflatedView)
            }
        }
        val inflatedView = LayoutInflater.from(p0.context).inflate(R.layout.adapter_tagoverview, p0, false)


        return ViewHolder(inflatedView)

    }

    override fun getItemCount(): Int {
        return content.size
    }




    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {

        when(viewHolder.itemViewType){
            0->{
                viewHolder.text.text=content[position].name
                viewHolder.text.backgroundTintList= ColorStateList.valueOf( Color.parseColor(content[position].color))
                viewHolder.itemView.setOnClickListener {
                    content.removeAt(viewHolder.adapterPosition)
                    notifyItemRemoved(viewHolder.adapterPosition)

                }
            }
            1->{
                viewHolder.text.text=content[position].name
                viewHolder.text.backgroundTintList= ColorStateList.valueOf( Color.parseColor(content[position].color))
                viewHolder.itemView.setOnClickListener {
                    content.removeAt(viewHolder.adapterPosition)
                    notifyItemRemoved(viewHolder.adapterPosition)

                }
            }
        }

    }




    fun getStrings(): Array<String> {
        var arr:Array<String> = emptyArray()
        for (subtag in content){
          arr=  arr.plus(subtag._id)
        }
        return arr
    }

    fun getSubtags(): ArrayList<Tag> {
        return content
    }


    class ViewHolder(v: View) : RecyclerView.ViewHolder(v), View.OnClickListener {
        val text:TextView=v.findViewById(R.id.txt_overview)


        init {
        }

        override fun onClick(v: View) {
        }

    }
}