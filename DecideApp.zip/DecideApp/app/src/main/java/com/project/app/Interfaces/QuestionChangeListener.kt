package com.project.app.Interfaces

import com.project.app.Objects.Question
import com.project.app.Objects.Update

interface QuestionChangeListener {
    fun onUpdate(timestamp:String,question: List<Question>)
    fun onError(er:String)
}