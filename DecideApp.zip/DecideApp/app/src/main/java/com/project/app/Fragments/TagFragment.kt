package com.project.app.Fragments

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.support.constraint.Group
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import com.project.app.Activities.MainActivity
import com.project.app.Adapters.SubTagAdapter
import com.project.app.Adapters.TagAdapter
import com.project.app.Adapters.TagOverviewAdapter
import com.project.app.Interfaces.TagInterface
import com.project.app.Objects.Tag
import com.project.app.R
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import com.project.app.Helpers.LocalBase
import kotlin.collections.ArrayList
import kotlin.collections.HashMap


class TagFragment : Fragment() {

    var savedTags: ArrayList<String>? = ArrayList()
    private var unsorted_tags: List<Tag> = ArrayList()
    private var tags: Map<String, List<Tag>> = HashMap()
    lateinit var main: RecyclerView
    lateinit var detail: RecyclerView
    lateinit var overview: RecyclerView
    lateinit var search: RecyclerView

    private lateinit var parent: MainActivity
    private lateinit var currentTopTag: Tag
    lateinit var search_icon: ImageView
    lateinit var search_clear: ImageView
    lateinit var search_back: ImageView

    lateinit var search_edittext: EditText

    lateinit var groupCover: Group
    lateinit var groupContent: Group


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        var view = inflater.inflate(R.layout.fragment_tag_new, null)


        main = view.findViewById<RecyclerView>(R.id.recycler_main)
        detail = view.findViewById<RecyclerView>(R.id.recycler_detail)
        overview = view.findViewById<RecyclerView>(R.id.tag_overview_recycler)
        search = view.findViewById(R.id.recycler_search)

        main.setHasFixedSize(true)
        detail.setHasFixedSize(true)
        overview.setHasFixedSize(true)
        search.setHasFixedSize(true)

        main.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        detail.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        overview.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        search.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)

        val loader = view.findViewById<ProgressBar>(R.id.progressbar_tag)

        loader.visibility = View.VISIBLE
        main.setOnClickListener {
            detail.visibility = View.GONE

        }
        main.setOnTouchListener { v, event ->
            detail.visibility = View.GONE
            true
        }
        search_icon = view.findViewById<ImageView>(R.id.search_tag)
        search_back = view.findViewById<ImageView>(R.id.search_back)

        search_clear = view.findViewById<ImageView>(R.id.search_clear)
        search_edittext = view.findViewById<EditText>(R.id.search_edit)

        groupContent = view.findViewById(R.id.search_content_group)
        groupCover = view.findViewById(R.id.search_cover_group)

        search_back.setOnClickListener {
            toggleTagSearch()
        }


        search_clear.setOnClickListener {
            search_edittext.text.clear()

        }
        view.findViewById<ImageView>(R.id.search_tag).setOnClickListener {
            toggleTagSearch()
        }

        search_edittext.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchTags(s.toString())
            }
        })

        loadTags(object : TagInterface {
            override fun onTags(context: List<Tag>, mmap: Map<String, List<Tag>>) {
                if (!mmap.keys.isEmpty()) {
                    loader.visibility = View.GONE
                }

                this@TagFragment.tags = mmap
                this@TagFragment.unsorted_tags = context
                main.adapter = mmap["-1"]?.let { TagAdapter(it, this@TagFragment) }
            }

            override fun onError() {
            }
        })

        return view
    }

    fun searchTags(txt: String) {
        var filtered = unsorted_tags.filter { tag -> tag.name.contains(txt) }
        Log.e("searchResult: ", "DAA: " + filtered.size + "  " + unsorted_tags.size)
        if(search.adapter!=null){
        (search.adapter as SubTagAdapter).content = filtered
        (search.adapter as SubTagAdapter).notifyDataSetChanged()}

    }


    fun showKeyboard(activity: View) {
        val imm = activity.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
        //   imm.showSoftInput(activity, InputMethodManager.SHOW_IMPLICIT)
    }

    fun hideKeyboard(activity: Context) {
        val view = view?.rootView?.windowToken
        if (view != null) {
            val imm = activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager?
            imm!!.hideSoftInputFromWindow(view, 0)
        }
    }

    private fun toggleTagSearch() {

        if (groupCover.visibility == View.VISIBLE) {
            //OPEN SEARCH
            groupContent.visibility = View.VISIBLE
            groupCover.visibility = View.GONE
            search.adapter = SubTagAdapter(unsorted_tags, this,true)
            search_icon.setImageResource(R.drawable.round_arrow_back_24)
            //   main.visibility=View.GONE
            // detail.visibility=View.GONE
            search.visibility = View.VISIBLE
            search_edittext.setOnFocusChangeListener { v, hasFocus ->
                Log.e("ONFOCS", "F:$hasFocus")
                if (hasFocus)
                    showKeyboard(search_edittext)
            }

            Handler().postDelayed({
                //doSomethingHere()

                Log.e("ONFOCSNOW", """sss""")


                search_edittext.isFocusableInTouchMode = true;
                search_edittext.requestFocus()
            }, 200)


            // showKeyboard(search_edittext)

        } else {
            groupContent.visibility = View.GONE
            groupCover.visibility = View.VISIBLE
            search_icon.setImageResource(R.drawable.baseline_search_24)
            //   main.visibility=View.VISIBLE
            search.visibility = View.GONE
            search_edittext.clearFocus()
            search_edittext.text.clear()
            context?.let { hideKeyboard(it) }
        }
    }

    fun addTag(subTag: Tag) {
        if (overview.adapter == null) {
            overview.adapter = TagOverviewAdapter(ArrayList(),true)
        }
        overview.visibility=View.VISIBLE
        (overview.adapter as TagOverviewAdapter).content.add(0, subTag)
        (overview.adapter as TagOverviewAdapter).notifyItemInserted(0)
        overview.smoothScrollToPosition(0)


    }

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        if (context is Activity) {
            parent = context as MainActivity
        }
    }

    fun setSubTag(tag: Tag) {
        if (!::currentTopTag.isInitialized) {
            currentTopTag = tag
        } else {
            if (currentTopTag == tag && detail.visibility == View.VISIBLE) {

                detail.visibility = View.GONE
                return
            } else if (currentTopTag == tag) {
                detail.visibility = View.VISIBLE

            }
        }



        currentTopTag = tag
        detail.visibility = View.VISIBLE


        when (tag._id) {
            TagAdapter.FAV_CONST -> {
                var favTags = getFavoriteTags()
                Log.e("TAGG", "FAVORITES" + favTags.size)
                detail.adapter = favTags?.let { SubTagAdapter(it, this@TagFragment) }
            }
            else -> {
                detail.adapter = tags[tag._id]?.let {
                    SubTagAdapter(it, this@TagFragment,true)
                }
                if ((detail.adapter as SubTagAdapter).content.isEmpty()) {
                    detail.visibility = View.INVISIBLE
                } else {
                    detail.visibility = View.VISIBLE

                }
            }
        }

    }

    fun getFavoriteTags(): ArrayList<Tag> {
        if (context != null) {
            savedTags = LocalBase(context!!).getFavoriteTags()
            Log.e("getFavoriteTags", "DATA: " + savedTags?.size)
            var tagContent = ArrayList<Tag>()
            if (savedTags != null) {
                for (tag in savedTags!!) {
                    val tag_f: Tag? = unsorted_tags.find { it._id == tag }
                    if (tag_f == null) {
                        //Tag gespeichert aber nicht in der Liste gefunden
                    } else {
                        //Tag gespeichert und auch online gefunden-> Anzeigen
                        tagContent.add(tag_f)
                    }
                }
            }
            return tagContent
        }
        return ArrayList()

    }

    fun loadTags(tagInterface: TagInterface) {
        if (!::parent.isInitialized) return
        parent.getSocketBase().getTags(tagInterface)
    }

    fun getTags(): ArrayList<Tag> {
        return (overview.adapter as TagOverviewAdapter).getSubtags()

    }

    fun toggleFavoriteTag(tag: Tag): Boolean {
        context?.let {   val res=LocalBase(it).toggleFavoriteTags(tag.parent)
            getFavoriteTags()
            return res}
        return false
    }

    fun toggleFavoriteAllTag(tag: Tag):Boolean {

        context?.let {
            val res=LocalBase(it).toggleFavoriteAllTags(tag.parent, tags, unsorted_tags)
            getFavoriteTags()
            return res}
        return false

    }

    fun allTagsInCatSaved(parent: String): Boolean {
        context?.let { return LocalBase(it).allTagsInCatSaved(parent, tags, unsorted_tags) }
        return false
    }

}