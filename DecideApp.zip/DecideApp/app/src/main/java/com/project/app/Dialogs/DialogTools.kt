package com.project.app.Dialogs

import android.app.Activity
import android.content.DialogInterface
import android.support.v7.app.AlertDialog
import com.project.app.R

class DialogTools {
    companion object{
        fun createDefaultDialog(activity:Activity,title:String,desc:String,positivemsg:String,negativemsg:String, positiveCallback:DialogInterface.OnClickListener,  negativeCallback:DialogInterface.OnClickListener ){


            val alertDialog: AlertDialog? = activity.let {
                val builder = AlertDialog.Builder(it)
                builder.apply {
                    setPositiveButton(
                        positivemsg,positiveCallback)
                    setNegativeButton(negativemsg,negativeCallback)
                    setTitle(title)
                    setMessage(desc)
                }

                builder.create()
            }
            alertDialog?.show()

        }
    }
}