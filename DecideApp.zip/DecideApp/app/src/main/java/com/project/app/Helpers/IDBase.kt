package com.project.app.Helpers

class IDBase {
    companion object {
        fun getID(): String {
            return "t"
        }
    }
}