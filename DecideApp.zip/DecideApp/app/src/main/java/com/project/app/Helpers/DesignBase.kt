package com.project.app.Helpers

import android.content.Context
import android.graphics.Color
import android.view.Window
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.data.PieDataSet
import com.project.app.R

class DesignBase {

    companion object {
        val BAR_QUESTION_TEXT2 = 1

        fun getPrimaryColor(): Int {
            return Color.WHITE
        }

        fun setNavigationBarColor(window: Window) {
            window.navigationBarColor = getPrimaryColor()

        }

        fun setStatusBarColor(window: Window) {
            window.statusBarColor = getPrimaryColor()

        }

        fun removeChartLabels( barChart: BarChart) {
            barChart.description = null
            barChart.setDrawGridBackground(false)
            barChart.setDrawValueAboveBar(false)
            barChart.setDrawMarkers(false)
            barChart.onTouchListener = null
            barChart.setNoDataText(null)
            barChart.legend.isEnabled = false

            barChart.axisLeft.setDrawLabels(false)
            barChart.axisRight.setDrawLabels(false)
            barChart.xAxis.setDrawLabels(false)
            barChart.axisRight.setDrawGridLines(false)
            barChart.axisLeft.setDrawGridLines(false)
            barChart.axisLeft.setDrawAxisLine(false)
            barChart.axisRight.setDrawAxisLine(false)
            barChart.xAxis.setDrawAxisLine(false)

            barChart.xAxis.setDrawGridLines(false)
            barChart.setDrawBorders(false)
            barChart.setDrawMarkers(false)

        }
        fun removeChartLabels( barChart: PieChart) {
            barChart.description = null

            barChart.setDrawMarkers(false)
            barChart.onTouchListener = null
            barChart.setNoDataText(null)
            barChart.legend.isEnabled = false
            barChart.setDrawMarkers(false)
            barChart.setDrawCenterText(false)
            barChart.setDrawEntryLabels(false)

        }


        fun styleChartData(ident: Int, dataSet: BarDataSet) {

            when(ident){
                BAR_QUESTION_TEXT2->{
                    dataSet.setColor(Color.WHITE,255)
                    dataSet.setDrawValues(false)




                }
            }

        }

        fun removeChartLabels(barChart: LineChart) {
            barChart.description = null
            barChart.setDrawBorders(false)
            barChart.setDrawGridBackground(false)
            barChart.xAxis.setDrawGridLines(false)
            barChart.xAxis.setDrawAxisLine(false)
            barChart.axisLeft.setDrawGridLines(false)
            barChart.axisLeft.setDrawAxisLine(false)
            barChart.xAxis.position = XAxis.XAxisPosition.BOTTOM
            //    barChart.xAxis.setDraw(false)
            barChart.setExtraOffsets(20f,10f,10f,10f)
            barChart.setDrawMarkers(false)
            barChart.onTouchListener = null
            barChart.setNoDataText(null)
            barChart.legend.isEnabled = false

        }

        fun setUpLineDataSet(dataSet_a1:LineDataSet, color: Int){
            dataSet_a1.setDrawCircles(true)
            dataSet_a1.setCircleColor(color)
            dataSet_a1.circleRadius = 3f
            dataSet_a1.lineWidth = 3f
            dataSet_a1.color = color
            dataSet_a1.setDrawValues(false)
            dataSet_a1.cubicIntensity = 0.05f
            dataSet_a1.mode = LineDataSet.Mode.CUBIC_BEZIER


        }

        fun setUpPieDataSet(pieDataSet: PieDataSet, context: Context?) {
            if(context==null)return
            pieDataSet.setDrawValues(false)
            pieDataSet.sliceSpace = 1.2f
            pieDataSet.setColors(
                context.resources.getColor(R.color.color_a1, null),
                context.resources.getColor(R.color.color_a2, null)
            )

        }

    }
}