package com.project.app.Helpers

import android.annotation.SuppressLint
import android.provider.Settings
import android.util.Log
import com.github.nkzawa.emitter.Emitter
import com.github.nkzawa.socketio.client.IO
import com.github.nkzawa.socketio.client.Socket
import com.project.app.Activities.MainActivity
import com.project.app.Objects.Question
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import com.squareup.moshi.Moshi
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Types
import java.lang.reflect.Type
import com.google.gson.Gson
import com.project.app.Interfaces.*
import com.project.app.Objects.Tag
import com.project.app.Objects.Update
import kotlinx.coroutines.Dispatchers
import java.util.*
import java.text.SimpleDateFormat
import kotlin.collections.ArrayList


class SocketBase(acti: MainActivity) {

    var lastUpdateTime: Long= 0L
    private val activity: MainActivity = acti
    var socket: Socket = IO.socket("http://192.168.178.21:80")

    interface SocketConnectionInterface {
        fun onConnected()
        fun onFailed()
        fun onDisconnected()
    }

    interface ContentInterface {
        fun onUpdate(questionData: List<Question>, time: Long)
        fun onError()
    }

    interface QuestionInterface {
        fun onSent()
        fun onFailed()

    }

    fun sendQuestionToServer(question: Question,callback: QuestionInterface) {
        val gson = Gson()

        val str: String = gson.toJson(question)


        socket.once(
            "onQuestionReceived"
        ) {
            callback.onSent()
            Log.e("onQuestionReceived", "YES!")

        }
        socket.emit("onNewQuestion", str)

    }


    fun connectAsync(callback: SocketConnectionInterface = activity, useCallback: Boolean = true) {

        GlobalScope.launch {
            try {
                if (socket.connected()) {
                    if (useCallback) callback.onConnected()
                } else {
                    socket.connect()
                    socket.off("connect")
                    socket.on("connect") {
                        Log.e("CONNECTED", "CCasdasd: " + IO.socket("http://192.168.178.21:3000"))
                        lastUpdateTime=Date().time
                        if (useCallback) {
                            callback.onConnected()
                        }

                    }
                    socket.off("disconnect")
                    socket.on("disconnect") {
                        if (useCallback) {

                            callback.onDisconnected()
                        }
                    }
                }


            } catch (exep: Throwable) {
                if (useCallback) callback.onFailed()
            }
        }
    }

    @SuppressLint("HardwareIds")
     fun generateUserID(): String {
        return Settings.Secure.getString(activity.contentResolver, Settings.Secure.ANDROID_ID);

    }

    fun fetchUpdatesBeforeTimestamp(param: ContentInterface,timestamp: String) {


        Log.e("SF", "FETCH UPDATES!!!!!!!!!!!!!")

        socket.once(
            "onQuestionsBeforeTimestamp"
        ) { args ->
            GlobalScope.launch {
                val moshi = Moshi.Builder().build()

                var type: Type = Types.newParameterizedType(List::class.java, Question::class.java)
                var adapter: JsonAdapter<List<Question>> = moshi.adapter(type)
                var questionData: List<Question> = adapter.fromJson(args[1].toString())!!

                var timeUpdateFetched = args[0] as Long

                Log.e("SF", "DATAqq: " + args[1]+"  "+questionData.size)


                GlobalScope.launch(Dispatchers.Main) {
                    param.onUpdate(questionData, timeUpdateFetched)
                }

            }
        }
        socket.emit("getQuestionsBeforeTimestamp",timestamp)

    }



    fun fetchUpdatesAfterTimeStamp(param: ContentInterface, timestamp: String) {


        Log.e("SF", "FETCH UPDATES!!!!!!!!!!!!!")

        socket.once(
            "onQuestionsAfterTimestamp"
        ) { args ->
            GlobalScope.launch {
                val moshi = Moshi.Builder().build()

                var type: Type = Types.newParameterizedType(List::class.java, Question::class.java)
                var adapter: JsonAdapter<List<Question>> = moshi.adapter(type)
                var questionData: List<Question> = adapter.fromJson(args[1].toString())!!

                var timeUpdateFetched = args[0] as Long

                Log.e("SF", "DATA: " + args[1])


                GlobalScope.launch(Dispatchers.Main) {
                    param.onUpdate(questionData, timeUpdateFetched)
                }

            }
        }
        socket.emit("getQuestionsAfterTimestamp",timestamp)

    }


    fun stopNotifyOnNewQuestions() {
        Log.e("NOTIFFFFFF","STOP TIMER")

        socket.emit("stopNotifyOnNewQuestions")
        socket.off("onNotifyOnNewQuestions")

    }

    fun getVotesForUser(userid:String,questionid: String, voteInterface: VoteInterface){
        socket.once(
            "onVotesForUser"
        ) { args ->
            GlobalScope.launch {

                val moshi = Moshi.Builder().build()

                var type: Type = Types.newParameterizedType(List::class.java,Update::class.java)
                var adapter: JsonAdapter<List<Update>> = moshi.adapter(type)
                Log.e("GET VOTES FOR USER", "DATA: " + args[1])

                if(args[1]!=null){
                    var questionData: List<Update> = adapter.fromJson(args[1].toString())!!
                    if(questionData.isNotEmpty()){
                    GlobalScope.launch(Dispatchers.Main) {
                        voteInterface.onVotesReceived(questionData[0])
                    }}
                }







            }
        }
        socket.emit("getVotesForUser",userid,questionid)

    }
    fun notifyOnNewQuestions(timestamp: String, notifyInterface: NotifyInterface){
        Log.e("NOTIFFFFFF","START TIMER")
        socket.off("onNotifyOnNewQuestions")
        socket.on("onNotifyOnNewQuestions") { args->
        notifyInterface.onNewCount(args[1] as Int, args[0].toString())
            Log.e("onNotifyOnNewQuestion","DDD: "+args[1])
        }
        socket.emit("notifyOnNewQuestions", timestamp)

    }

    fun getTags(param: TagInterface) {

        socket.once(
            "onTags"
        ) { args ->
            GlobalScope.launch {
                val moshi = Moshi.Builder().build()

                var type: Type = Types.newParameterizedType(List::class.java, Tag::class.java)
                var adapter: JsonAdapter<List<Tag>> = moshi.adapter(type)
                var questionData: List<Tag> = adapter.fromJson(args[1].toString())!!

                var timeUpdateFetched = args[0] as Long

                Log.e("SF", "DATA: " + args[1]+"  "+questionData.size)

                var mmap= questionData.groupBy { it.parent }

                GlobalScope.launch(Dispatchers.Main) {
                    param.onTags(questionData.filter { tag->tag.parent!="-1" },mmap)
                }

            }
        }
        socket.emit("getTags")

    }

    fun isConnected(): Boolean {
        return socket.connected()

    }

    fun questionAnswered(question: Question, numberOfAnswer: Int) {

        socket.emit("onQuestionAnswered", question._id, numberOfAnswer, question.userid)

    }

    /**
     * Erster Listener für Änderungen an Frage, auch wenn ein Vote dazu kommt!
     * Zweiter Listener für Updates, also wenn jemand ein Update dazu erstelle!!!
     */
    fun addUpdatesToQuestion(
        question: Question,
        questionChangeListener: QuestionChangeListener?,
        historyListener: UpdateListener?
    ) {

        val listener = Emitter.Listener { args ->

            val moshi = Moshi.Builder().build()

            var type: Type = Types.newParameterizedType(List::class.java, Question::class.java)
            var adapter: JsonAdapter<List<Question>> = moshi.adapter(type)

            var type2: Type = Types.newParameterizedType(List::class.java, Update::class.java)
            var adapter2: JsonAdapter<List<Update>> = moshi.adapter(type2)

            Log.e("addUpdatesToQuestion","DATA: "+args[1]+"   \n"+args[2])
            var questionData: List<Question> = adapter.fromJson(args[1].toString())!!
            var questionData2: List<Update>? = null
            if (args.size >= 3) {
                questionData2 = adapter2.fromJson(args[2].toString())!!
            }

            var timeUpdateFetched = args[0]

            GlobalScope.launch(Dispatchers.Main) {
                questionChangeListener?.onUpdate(timeUpdateFetched.toString(), questionData)
                if (questionData2 != null) historyListener?.onUpdatesReady(
                    ArrayList(questionData2),
                    timeUpdateFetched.toString().toLong()
                )
            }


        }
        socket.off("updateForRegisteredQuestion")
        socket.on("updateForRegisteredQuestion", listener)

        socket.emit("registerUpdateForQuestions", question._id, question.updated)


    }

    fun removeUpdatesFromQuestion(question: Question) {

            socket.emit("removeUpdateForQuestions", question._id)





    }

    fun getUpdates(questionID: String, updateListener: UpdateListener) {


            socket.once(
                "onUpdates"
            ) { args ->
                GlobalScope.launch {
                    val moshi = Moshi.Builder().build()

                    var type: Type = Types.newParameterizedType(List::class.java, Update::class.java)
                    var adapter: JsonAdapter<ArrayList<Update>> = moshi.adapter(type)
                    var questionData: ArrayList<Update> = adapter.fromJson(args[1].toString())!!

                    var timeUpdateFetched = args[0] as Long

                    Log.e("SF", "DATA: " + args[1])


                    GlobalScope.launch(Dispatchers.Main) {
                        updateListener.onUpdatesReady(questionData, timeUpdateFetched)
                    }

                }
            }
            socket.emit("getUpdatesByQuestion", questionID)



    }



}