package com.project.app.Objects

class Tag {
    var _id: String = "-1"
    var name:String="-1"
    var enabled:Boolean=true
    var parent:String = "-2"
    var color: String ="-1"

    constructor(_id: String, name: String, enabled: Boolean, parent: String, color:String) {
        this._id = _id
        this.name = name
        this.enabled = enabled
        this.parent = parent
        this.color=color
    }
}