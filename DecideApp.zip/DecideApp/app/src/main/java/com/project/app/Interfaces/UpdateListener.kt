package com.project.app.Interfaces

import com.project.app.Objects.Update

interface UpdateListener {
    fun onUpdatesReady(content:ArrayList<Update>, timest:Long)
    fun onFailed()
}