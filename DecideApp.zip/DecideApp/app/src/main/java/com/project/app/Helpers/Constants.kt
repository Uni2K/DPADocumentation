package com.project.app.Helpers

class Constants {
    companion object {

        const val STATUS_CONNECTED = "-100"
        const val STATUS_DISCONNECTED = "-110"

        const val STATUS_UNKNOWN_FAILED = "-999"
        const val STATUS_CONNECTION_FAILED = "-998"
        const val STATUS_UPDATE_FETCH_FAILED = "-996"
        const val STATUS_UPDATE_FETCH_START = "-995"
        const val STATUS_UPDATE_FETCH_FINISHED = "-994"

        const val STATUS_ID_FAILED = "-997"
        const val STATUS_INTERNET_FAILED = "-101"
        const val STATUS_STARTING = "-2"

        const val EXAMPLE_ID = 1233


        const val VP_POS_HOME = 2
        const val VP_POS_TRENDING = 1
        const val VP_POS_STREAM = 0

        const val SAVE_FAV="FavTags"
    }
}