package com.project.app.Adapters

import android.content.res.ColorStateList
import android.graphics.Color
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.project.app.Fragments.QuestionCreateDialogFragment
import com.project.app.Fragments.TagFragment
import com.project.app.Objects.Tag
import com.project.app.R


class SubTagAdapter(
    var content: List<Tag>,
    val parent: TagFragment,
    val firstAll: Boolean = false
) :
    RecyclerView.Adapter<SubTagAdapter.ViewHolder>() {
    var mRecyclerView: RecyclerView? = null

    init {
     if(firstAll)   parent.getFavoriteTags()
    }

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        mRecyclerView = recyclerView
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): ViewHolder {
        val inflatedView = LayoutInflater.from(p0.context).inflate(R.layout.adapter_tag, p0, false)


        return ViewHolder(inflatedView)
    }

    override fun getItemCount(): Int {
        return if (firstAll) content.size + 1
        else content.size
    }


    override fun getItemViewType(position: Int): Int {

        return if (position == 0 && firstAll) 1 else 0

    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {

        when (viewHolder.itemViewType) {
            0 -> {
                var c2 = 0
                if (firstAll) c2 = position - 1
                else c2 = position
                viewHolder.name.text = content[c2].name
                viewHolder.itemView.backgroundTintList =
                    ColorStateList.valueOf(Color.parseColor(content[c2].color))
                viewHolder.c2.setBackgroundColor(Color.parseColor(content[c2].color))
                viewHolder.c1.setColorFilter(
                    Color.parseColor(content[c2].color),
                    android.graphics.PorterDuff.Mode.SRC_IN
                )
                val c = Color.parseColor(content[c2].color)


                Log.e(
                    "TEST",
                    "DATA: " + content[c2]._id + "  " + parent.savedTags?.find { it == content[c2]._id } + "  " + parent.savedTags
                )
                if (parent.savedTags?.find { it == content[c2]._id } != null) {
                    viewHolder.heart.setImageResource(R.drawable.baseline_favorite_24)

                } else
                    viewHolder.heart.setImageResource(R.drawable.baseline_favorite_border_24)

                viewHolder.heart.setColorFilter(c, android.graphics.PorterDuff.Mode.SRC_IN)
                viewHolder.heart.setOnClickListener {


                    if (parent.toggleFavoriteTag(content[c2])) {
                        viewHolder.heart.setImageResource(R.drawable.baseline_favorite_24)

                    } else
                        viewHolder.heart.setImageResource(R.drawable.baseline_favorite_border_24)


                }

            }
            1 -> {
                //First ITEM
                viewHolder.name.text = "Select All"
                if (parent.allTagsInCatSaved(content[position].parent)) {
                    viewHolder.heart.setImageResource(R.drawable.baseline_favorite_24)

                } else
                    viewHolder.heart.setImageResource(R.drawable.baseline_favorite_border_24)

                viewHolder.heart.setOnClickListener {
                    //ADD ALL TO FAVORITES
                    if (parent.toggleFavoriteAllTag(content[position])) {
                        //ALL TAGS SAVED->REMOVE ALL
                        viewHolder.heart.setImageResource(R.drawable.baseline_favorite_border_24)
                        notifyDataSetChanged()
                    } else {
                        viewHolder.heart.setImageResource(R.drawable.baseline_favorite_24)
                        notifyDataSetChanged()
                    }
                }


            }

        }
        viewHolder.itemView.setOnClickListener {

            parent.addTag(content[position])


        }

    }


    class ViewHolder(v: View) : RecyclerView.ViewHolder(v), View.OnClickListener {
        val name: TextView = v.findViewById(R.id.tag_name)
        val c1: ImageView = v.findViewById(R.id.tag_c1)
        val c2: View = v.findViewById(R.id.tag_c2)
        val heart: ImageView = v.findViewById(R.id.tag_heart)

        init {
        }

        override fun onClick(v: View) {
        }

    }
}