package com.project.app.Fragments

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.project.app.Interfaces.AdditionalScreenInterface
import com.project.app.R



class HomeFragment: Fragment() {
    lateinit var callback: AdditionalScreenInterface
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
       var view=inflater.inflate(R.layout.fragment_home, null)


        return view
    }



}