package com.project.app.Interfaces

import com.project.app.Objects.Update

interface VoteInterface {
    fun onVotesReceived(args: Update)
}