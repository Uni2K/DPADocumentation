package com.project.app.Interfaces

interface TimeInterface {
    fun onUpdate(arg:Double)
}