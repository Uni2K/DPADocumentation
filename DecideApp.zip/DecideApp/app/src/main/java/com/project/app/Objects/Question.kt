package com.project.app.Objects

import android.support.v7.util.DiffUtil


open class Question : Comparable<Question> {
    /**
     * Wenn Text und Antworten sich ändern, wird das nur als Textänderung erkannt
     */
    override fun compareTo(other: Question): Int {

        //Different Question
        if (this._id != other._id) return 0
        //Different Text
        if (this.text != other.text) return 1
        if (this.enabled != other.enabled) return 3

        if (!(this.answers contentEquals other.answers)) return 4
        if (!(this.votes contentEquals other.votes)) return 5

        if (this.userid != other.userid) return 6

        if (this.timestamp != other.timestamp) return 7

        if(this.context !=other.context)return 8
        if(!(this.tags contentEquals other.tags)) return 9
        if(this.country!=other.country)return 11




        //Everything the same
        return 10

    }

    var _id: String = "-1"
    var text: String = "-1"
    var userid: String = "-1"
    var timestamp: String = "-1"
    var enabled = true
    var answers = emptyArray<String>()
    var tags = emptyArray<Tag>()
    var votes = emptyArray<Int>()
    var context:String="-1"
    var country:String="-1"
    var updated:String="-1"








    constructor(
        id: String,
        text: String,
        userid: String,
        timestamp: String,
        enabled: Boolean,
        answers: Array<String>,
        votes: Array<Int>,
        tags: Array<Tag>,
        country:String,
        context:String,
        updated:String
    ) {
        this._id = id
        this.text = text
        this.userid = userid
        this.timestamp = timestamp
        this.enabled = enabled
        this.answers = answers
        this.votes = votes
        this.context=context
        this.country=country
        this.tags=tags
        this.updated=updated
    }
}