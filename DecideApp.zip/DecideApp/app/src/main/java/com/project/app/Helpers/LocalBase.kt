package com.project.app.Helpers

import android.content.Context
import com.google.gson.reflect.TypeToken
import com.google.gson.Gson
import android.preference.PreferenceManager
import android.util.Log
import com.project.app.Objects.Tag
import com.project.app.Objects.Update


class LocalBase(val context: Context) {


    var storedVotes: HashMap<String, Update> = HashMap()
    private val storeKEY = "voteMap"
    private val gson = Gson()

    init {
        var x = getHashMap(storeKEY)
        if (x == null) {
            saveHashMap(storeKEY, HashMap<String, Update>(), true)
        } else {
            storedVotes = x
        }

    }


    fun addVote(update: Update) {
        if (getVote(update.questionid) == null)
            storedVotes[update.questionid] = update
        saveHashMap(storeKEY, storedVotes)
    }

    fun getVote(questionid: String): Update? {
        return storedVotes[questionid]

    }

    private fun saveHashMap(key: String, obj: Any, now: Boolean = false) {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        val editor = prefs.edit()
        val json = gson.toJson(obj)
        editor.putString(key, json)
        if (now) editor.commit()
        else editor.apply()
        Log.d("LocalBase", "VOTESTORAGE angepasst!: $key")
    }


    fun getHashMap(key: String): HashMap<String, Update>? {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        val json = prefs.getString(key, "")
        val type = object : TypeToken<HashMap<String, Update>>() {

        }.type
        return gson.fromJson<Any>(json, type) as HashMap<String, Update>?
    }

    fun getFavoriteTags(): ArrayList<String>? {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        val json = prefs.getString(Constants.SAVE_FAV, "")
        val type = object : TypeToken<ArrayList<String>>() {

        }.type
        return gson.fromJson<Any>(json, type) as ArrayList<String>?
    }

    /**
     * Retrun True if added to Tags, makes sure editor can work in background and data gets updated faster in Adapter
     */
    fun toggleFavoriteTags(tagid: String): Boolean {
        var arr = getFavoriteTags()
        if (arr == null) arr = ArrayList()
        var returnitus = false
        if (arr.find { it == tagid } == null) {
            //Not in List
            arr.add(tagid)
            returnitus = true
        } else {
            arr.remove(tagid)
            returnitus = false
        }
        Log.e("toggleFavoriteTags", "DATA: " + arr?.size + "  " + returnitus)

        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        val editor = prefs.edit()
        val json = gson.toJson(arr)
        editor.putString(Constants.SAVE_FAV, json)
        editor.commit()
        return returnitus
    }
    fun allTagsInCatSaved(
        parent: String,
        tags: Map<String, List<Tag>>,
        unsorted_tags: List<Tag>
    ): Boolean {

        //Tags stored as IDs not with parents
        //Create Tag List by saved TAGS from unsorted_tag
        //compare Tag List with Hashmap

        var arr = getFavoriteTags()

        if (arr == null) arr = ArrayList()
        var returnitus = false
        var tag_list = ArrayList<Tag>()
        for (tag in arr) {
            val add = unsorted_tags.find { it._id == tag }
            if (add != null) {
                tag_list.add(add)
            }
        }
        if (tag_list.isNotEmpty()) {
            val compareList = tags[parent]
            if (compareList != null) {
                val allTagsSaved = tag_list.containsAll(compareList)
                returnitus = allTagsSaved
            }
        }
        Log.e("allTagsinCatSAved", "ALL SAVED_:" + returnitus)

       return returnitus
    }

    fun toggleFavoriteAllTags(
        parent: String,
        tags: Map<String, List<Tag>>,
        unsorted_tags: List<Tag>
    ): Boolean {

        //Tags stored as IDs not with parents
        //Create Tag List by saved TAGS from unsorted_tag
        //compare Tag List with Hashmap

        var arr = getFavoriteTags()
        Log.e("toggleFavoriteAllTags", "BEGIN" + arr?.size)

        if (arr == null) arr = ArrayList()
        var returnitus = false
        var tag_list = ArrayList<Tag>()
        for (tag in arr) {
            val add = unsorted_tags.find { it._id == tag }
            if (add != null) {
                tag_list.add(add)
            }
        }
        if (tag_list.isNotEmpty()) {
            val compareList = tags[parent]
            if (compareList != null) {
                val allTagsSaved = tag_list.containsAll(compareList)
                returnitus = allTagsSaved
            }
        }

        if (returnitus) {
            //ALL TAGS SAVED, remove all
            val compareList = tags[parent]
            val newArr = ArrayList<String>()
            newArr.addAll(arr)
            for (tagS in arr) {
                if (compareList?.find { it._id == tagS } != null) {
                    //TAG IN CRITICAL CAT->remove
                    newArr.remove(tagS)
                }
            }
            arr = newArr
        } else {
            //NOT ALL TAGS SAVED->SAVE ALL
            val compareList = tags[parent]
            if (compareList != null) {
                for (tag in compareList) {
                    ///ADD ALL that are missing
                    if (!arr.contains(tag._id)) {
                        arr.add(tag._id)
                    }
                }

            }
        }
        Log.e("toggleFavoriteAllTags", "DATA: " + arr?.size + "  " + returnitus + "  " + parent)

        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        val editor = prefs.edit()
        val json = gson.toJson(arr)
        editor.putString(Constants.SAVE_FAV, json)
        editor.commit()
        return returnitus
    }

}