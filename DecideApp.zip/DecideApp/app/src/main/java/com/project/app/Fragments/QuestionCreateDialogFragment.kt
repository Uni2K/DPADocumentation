package com.project.app.Fragments

import android.app.Dialog
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.support.design.widget.Snackbar
import android.support.v4.app.DialogFragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.*
import android.widget.*
import com.project.app.Activities.MainActivity
import com.project.app.Adapters.TagAdapter
import com.project.app.Adapters.TagOverviewAdapter
import com.project.app.Helpers.SocketBase
import com.project.app.Interfaces.TagInterface
import com.project.app.Objects.Question
import com.project.app.Objects.Tag
import com.project.app.R
import java.util.*
import android.content.Context
import android.content.DialogInterface
import android.support.v4.app.Fragment
import android.view.inputmethod.InputMethodManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import android.widget.Toast
import android.view.KeyEvent.KEYCODE_ENTER
import com.project.app.Adapters.SubTagAdapter
import com.project.app.Dialogs.DialogTools
import kotlin.collections.ArrayList
import kotlin.collections.HashMap
import android.app.Activity
import android.support.v4.content.ContextCompat.getSystemService



//1559671861075 OLD TIME
//1559671924463 TIME SET
//1559671420018  CREATE DATE
class QuestionCreateDialogFragment : DialogFragment() {
    private lateinit var parent: MainActivity
    lateinit var edit_context: EditText
    lateinit var edit_text: EditText
    lateinit var edit_left: EditText
    lateinit var edit_right: EditText
    lateinit var master: ConstraintLayout
    lateinit var tag_pre: TextView
   // lateinit var terms: CheckBox
    fun showKeyboard(activity: Context?, view:View) {
       val imm = activity?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
       imm.showSoftInput(view, InputMethodManager.HIDE_NOT_ALWAYS)
    }


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val v = inflater.inflate(R.layout.fragment_question_create, container, false)

        edit_context = v.findViewById<EditText>(R.id.edit_context)
        master = v.findViewById(R.id.create_master)
        val cover_context = v.findViewById<LinearLayout>(R.id.cover_context)

        edit_context.setOnFocusChangeListener { v, hasFocus ->
            Log.e("CREATE FOCUS", "Context: $hasFocus")
            if (!hasFocus && edit_context.text.isEmpty()) {
                cover_context.visibility = View.VISIBLE
                edit_context.visibility = View.GONE
            }
            if (hasFocus) {
                showKeyboard(context,edit_context)
            }

        }

        cover_context.setOnClickListener {
            edit_context.visibility = View.VISIBLE
            cover_context.visibility = View.GONE
            edit_context.requestFocus()

        }
       // terms = v.findViewById(R.id.terms)
        edit_text = v.findViewById<EditText>(R.id.create_text)

        val cover_text = v.findViewById<LinearLayout>(R.id.cover_text)
        edit_text.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus && edit_text.text.isEmpty()) {
                cover_text.visibility = View.VISIBLE
                edit_text.visibility = View.GONE
            }
            if (hasFocus) {
                showKeyboard(context,edit_text)
            }
        }
        cover_text.setOnClickListener {
            edit_text.visibility = View.VISIBLE
            cover_text.visibility = View.GONE

            edit_text.requestFocus()

        }
        childFragmentManager.beginTransaction().replace(R.id.tagcontainer,TagFragment(),"tags").commit()


        edit_text.setOnKeyListener { v, keyCode, event ->
            if (keyCode == KEYCODE_ENTER) {
                edit_left.requestFocus()
                Log.e("ONKEY", "DATA: " + keyCode + "  " + event.action)

            }
            true
        }

        edit_left = v.findViewById<EditText>(R.id.create_left)

        val cover_left = v.findViewById<LinearLayout>(R.id.cover_left)
        edit_left.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus && edit_left.text.isEmpty()) {
                cover_left.visibility = View.VISIBLE
                edit_left.visibility = View.GONE
            }
            if (hasFocus) {
                edit_left.visibility = View.VISIBLE
                cover_left.visibility = View.GONE
                edit_left.requestFocus()
                showKeyboard(context,edit_left)
            }

        }
        cover_left.setOnClickListener {
            edit_left.visibility = View.VISIBLE
            cover_left.visibility = View.GONE
            edit_left.requestFocus()
            showKeyboard(context,edit_left)
            val imm = activity?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(edit_left, InputMethodManager.HIDE_NOT_ALWAYS)

        }

        edit_right = v.findViewById<EditText>(R.id.create_right)
        val cover_right = v.findViewById<LinearLayout>(R.id.cover_right)
        edit_right.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus && edit_right.text.isEmpty()) {
                cover_right.visibility = View.VISIBLE
                edit_right.visibility = View.GONE
            }
            if (hasFocus) {
                showKeyboard(context,edit_right)
            }
        }
        cover_right.setOnClickListener {
            edit_right.visibility = View.VISIBLE
            cover_right.visibility = View.GONE
            edit_right.requestFocus()
            showKeyboard(context,edit_right)


        }




        val toolbar = v.findViewById<android.support.v7.widget.Toolbar>(R.id.create_toolbar)

        toolbar.inflateMenu(R.menu.creator)
        toolbar.setNavigationOnClickListener {
            dismiss()
        }


        toolbar.setOnMenuItemClickListener() { item ->
            if (item != null) {
                when (item.itemId) {
                    R.id.save -> {
                        createQuestion()
                    }
                }
            }


            true

        }


        toolbar.title = "Create Question"


        return v
    }

    fun setParent(mainActivity: MainActivity) {
        this.parent = mainActivity
    }






    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.FullScreenDialogStyle)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        val dialog = super.onCreateDialog(savedInstanceState)
        dialog.window?.requestFeature(Window.FEATURE_NO_TITLE)





        return dialog
    }

    override fun onStart() {
        super.onStart()
        val dialog = dialog
        if (dialog != null) {
            dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
    }

    fun createQuestion() {

        val tagFragment=childFragmentManager.findFragmentByTag("tags") as TagFragment
        if (edit_text.text.length < 10) {
            showError(0)
            return
        }
        if (edit_left.text.length < 2 || edit_right.text.length < 2) {
            showError(1)
            return
        }

        if (tagFragment.getTags().size == 0) {
            showError(2)
            return
        }
      /*  if (!terms.isChecked) {

            showError(3)
            return
        }*/


        val question = Question(
            "1",
            edit_text.text.toString(),
            parent.getSocketBase().generateUserID(),
            Date().time.toString(),
            true,
            arrayOf(edit_left.text.toString(), edit_right.text.toString()),
            arrayOf(0, 0),
            tagFragment.getTags().toTypedArray(),
            "Germany",
            edit_context.text.toString(),
            Date().time.toString()

        )

        val imm = context?.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager?
        imm!!.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0)

        DialogTools.createDefaultDialog(parent,"Accept Rules","Do you accept the rules of this product? Sonst gibts heftigen Ärger!"
        , "YES","NO", DialogInterface.OnClickListener { dialog, which ->
                parent.getSocketBase().sendQuestionToServer(question, object : SocketBase.QuestionInterface {
                    override fun onSent() {
                        questionSent()
                    }

                    override fun onFailed() {
                    }
                })
                dialog.dismiss()
            },
            DialogInterface.OnClickListener { dialog, which ->
                dialog.dismiss()
            })



    }

    fun questionSent() {
        GlobalScope.launch(Dispatchers.Main) {
            Toast.makeText(context, "Successfully sent question!", Toast.LENGTH_LONG).show()
            dismiss()
        }

    }


    fun showError(type: Int) {
        var string = "ERROR"
        when (type) {
            0 -> string = "add a question"
            1 -> string = "add an answer"
            2 -> string = "add at least 1 tag"
            3 -> string = "accept the terms of usage"

        }
        Snackbar.make(master, string, Snackbar.LENGTH_SHORT).show()
    }


}