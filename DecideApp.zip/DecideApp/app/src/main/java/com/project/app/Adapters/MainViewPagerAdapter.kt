package com.project.app.Adapters

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter
import android.support.v4.app.FragmentStatePagerAdapter
import com.project.app.Fragments.HomeFragment
import com.project.app.Fragments.StreamFragment
import com.project.app.Fragments.TrendingFragment
import com.project.app.Helpers.Constants

class MainViewPagerAdapter(fragmentManager: FragmentManager) : FragmentPagerAdapter(fragmentManager) {


    private lateinit var homeFragment: Fragment
    lateinit var streamFragment: StreamFragment
    private lateinit var trendingFragment: Fragment

    fun isStreamInit():Boolean{
        return ::streamFragment.isInitialized
    }
    override fun getItem(p0: Int): Fragment {
        when (p0) {
            Constants.VP_POS_HOME -> {
                if (!::homeFragment.isInitialized)
                    homeFragment = HomeFragment()
                return homeFragment

            }
            Constants.VP_POS_TRENDING -> {
                if (!::trendingFragment.isInitialized)
                    trendingFragment = TrendingFragment()
                return trendingFragment


            }
            Constants.VP_POS_STREAM -> {
                if (!::streamFragment.isInitialized)
                    streamFragment = StreamFragment()
                return streamFragment

            }

        }
        return HomeFragment()
    }

    override fun getCount(): Int {
        return 1
    }


}

