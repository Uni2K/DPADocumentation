package com.project.app.Helpers

import android.os.Bundle
import android.support.v7.util.DiffUtil
import android.util.Log
import com.project.app.Objects.Question
import com.project.app.Objects.Update


class DiffUtilVoteCallback(val content: ArrayList<Question>, val update: Update) : DiffUtil.Callback() {

    override fun areItemsTheSame(p0: Int, p1: Int): Boolean {
        return true
    }

    override fun getOldListSize(): Int {
        return content.size
    }

    override fun getNewListSize(): Int {

        return content.size

    }

    override fun areContentsTheSame(p0: Int, p1: Int): Boolean {


        val result = content[p1]._id==update.questionid
        Log.d("areContentsTheSame", "DATA: $result  $p0  $p1")
        return !result
    }

    override fun getChangePayload(oldItemPosition: Int, newItemPosition: Int): Any? {

        val diff = Bundle()
        diff.putString("votesReceived", update.voteon.toString())
        diff.putString("votesQuestionID", update.questionid)


        Log.e("changePayload", "PAYLOAD" +diff.size()+"  "+update.voteon)
        if (diff.size() == 0) {
            return null
        }
        return diff
    }


}

