package com.project.app.Fragments

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.project.app.Activities.MainActivity
import com.project.app.Adapters.StreamAdapter
import com.project.app.Interfaces.UpdateListener
import com.project.app.Interfaces.QuestionChangeListener
import com.project.app.Interfaces.VoteInterface
import com.project.app.Objects.Question
import com.project.app.Objects.Tag
import com.project.app.R

class QuestionSwitchFragment : Fragment() {

    lateinit var activity: MainActivity
    lateinit var recycler_switch: RecyclerView
    lateinit var fullView:QuestionFullDialogFragment
    lateinit var questionData: ArrayList<Question>
    var tags:ArrayList<Tag> = ArrayList()
    override fun onAttach(context: Context?) {
        super.onAttach(context)
        if (context is Activity) {
            activity = context as MainActivity
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    fun showFullView(q:Question){
        if(!::fullView.isInitialized){
            fullView=QuestionFullDialogFragment()
        }
        fullView.setQuestion(q)
        fullView.setParent(this)
        fullView.show(childFragmentManager,"full")
    }
    fun removeFullView(){
        if(::fullView.isInitialized){
            fullView.dismiss()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        var view = inflater.inflate(R.layout.fragment_question_switcher, null)

        recycler_switch = view.findViewById<RecyclerView>(R.id.recycler_switch)

        if (::questionData.isInitialized) refreshUI(questionData)

        return view
    }


    fun update(data: ArrayList<Question>) {

        Log.e("QSF","UPDATE: "+data.size)
        refreshUI(data)

    }
    fun updateTags(data: ArrayList<Tag>) {
        this.tags=data

    }
    fun showError(error: String) {
        TODO("IMPLE")
    }

    fun refreshUI(content: ArrayList<Question>) {
        setRecyclerData(content)
    }



    private fun setRecyclerData(content: ArrayList<Question>) {
        questionData=content
        if (::recycler_switch.isInitialized ) {
            if(recycler_switch.adapter==null) {


                recycler_switch.layoutManager = LinearLayoutManager(context)
                recycler_switch.setHasFixedSize(true)
                recycler_switch.adapter = context?.let { StreamAdapter(content, it) }
                (recycler_switch.adapter as StreamAdapter).connectFragment(this)
                recycler_switch.invalidate()
            }else{
                (recycler_switch.adapter as StreamAdapter).updateItems(content)
            }
        }

    }





    fun questionAnswered(NumberOfAnswer:Int, question: Question) {
        Log.e("question Answered","DATA: "+questionData.size)
        activity.getSocketBase().questionAnswered(question, NumberOfAnswer)




    }
    fun getVotesForUser(question: Question, voteInterface: VoteInterface) {
        activity.getSocketBase().getVotesForUser(activity.getSocketBase().generateUserID(),question._id, voteInterface)

    }
    fun addUpdatesToQuestion(question: Question, questionChangeListener: QuestionChangeListener?, historyListener: UpdateListener?) {
        activity.getSocketBase().addUpdatesToQuestion(question,questionChangeListener,historyListener)

    }
    fun removeUpdatesFromQuestion(question: Question) {
        activity.getSocketBase().removeUpdatesFromQuestion(question)
    }




}