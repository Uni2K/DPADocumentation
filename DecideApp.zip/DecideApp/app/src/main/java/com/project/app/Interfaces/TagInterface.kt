package com.project.app.Interfaces

import com.project.app.Objects.Tag

interface TagInterface {
    fun onTags(
        context: List<Tag>,
        mmap: Map<String, List<Tag>>
    )
    fun onError()
}