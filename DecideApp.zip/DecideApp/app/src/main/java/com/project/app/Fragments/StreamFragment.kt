package com.project.app.Fragments

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.support.v4.app.Fragment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.project.app.Activities.MainActivity
import com.project.app.Helpers.SocketBase
import com.project.app.Interfaces.TagInterface
import com.project.app.Objects.Question
import com.project.app.Objects.Tag
import com.project.app.R

class StreamFragment : Fragment() {
    lateinit var activity: MainActivity
    lateinit var  frag:QuestionSwitchFragment
    lateinit var tags:ArrayList<Tag>

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        if (context is Activity) {
            activity = context as MainActivity
        }
    }

    fun fetchUpdatesBeforeTimestamp(){
        Log.e("SF","fetchUpdates")
        if(activity.getSocketBase().isConnected()) {
            Log.e("SF","fetchUpdates 1")

            activity.getSocketBase().fetchUpdatesBeforeTimestamp(object : SocketBase.ContentInterface {
                override fun onUpdate(questionData: List<Question>, time: Long) {
                 Log.e("SF","fetchUpdates 2")
                    if(! ::frag.isInitialized){
                        frag=QuestionSwitchFragment()
                    }
                    frag.update(ArrayList(questionData))
                    activity.hideProgress()
                }

                override fun onError() {
                    activity.startError()

                }
            }, activity.getSocketBase().lastUpdateTime.toString())
        }
    }


    override fun onStart() {
        super.onStart()
        fetchTagList()

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        var view = inflater.inflate(R.layout.fragment_stream, null)

        Log.e("SF","ONCREATEVIEW")
        if(! ::frag.isInitialized){
            frag=QuestionSwitchFragment()
        }
        childFragmentManager.beginTransaction().replace(R.id.stream_container,frag,"switch").commit()
       // frag.update()

        view.setOnClickListener {

          //  frag.update()

        }

        return view
    }

    fun fetchTagList(){
        activity.getSocketBase().getTags(object: TagInterface{
            override fun onTags(
                context: List<Tag>,
                mmap: Map<String, List<Tag>>
            ) {
                this@StreamFragment.tags=ArrayList(context)
                frag.updateTags(ArrayList(context))
            }

            override fun onError() {

            }
        })
    }



    fun fetchUpdatesAfterTimestamp(){
        if(activity.getSocketBase().isConnected()) {

            activity.getSocketBase().fetchUpdatesAfterTimeStamp(object : SocketBase.ContentInterface {
                override fun onUpdate(questionData: List<Question>, time: Long) {
                    if(questionData.isEmpty()){
                        activity.hideProgress()
                        return
                    }
                    Log.e("SF2222222","fetchUpdates 2"+  questionData[0].answers.size)
                    if(! ::frag.isInitialized){
                        frag=QuestionSwitchFragment()
                    }
                    activity.getSocketBase().lastUpdateTime=time
                    frag.update(ArrayList(questionData))
                    activity.updateNotyCount(0)
                    activity.hideProgress()

                }

                override fun onError() {
                    activity.hideProgress()
                    activity.startError()
                }
            }, activity.getSocketBase().lastUpdateTime.toString())
        }
    }

}