package com.project.app.Activities

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.support.constraint.ConstraintSet
import android.support.constraint.Group
import android.support.design.widget.BottomNavigationView
import android.support.design.widget.FloatingActionButton
import android.support.transition.TransitionManager
import android.support.transition.Visibility
import android.support.v4.view.ViewPager
import android.support.v4.widget.ImageViewCompat
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.*
import com.project.app.Adapters.MainViewPagerAdapter
import com.project.app.Helpers.*
import com.project.app.Helpers.Constants.Companion.STATUS_CONNECTED
import com.project.app.Helpers.Constants.Companion.STATUS_CONNECTION_FAILED
import com.project.app.Helpers.Constants.Companion.STATUS_ID_FAILED
import com.project.app.Helpers.Constants.Companion.STATUS_INTERNET_FAILED
import com.project.app.Helpers.Constants.Companion.STATUS_STARTING
import com.project.app.R
import kotlinx.android.synthetic.main.activity_main.*
import com.project.app.Fragments.QuestionCreateDialogFragment
import com.project.app.Fragments.StartupFragment
import com.project.app.Fragments.TagFragment
import com.project.app.Helpers.Constants.Companion.STATUS_DISCONNECTED
import com.project.app.Interfaces.AdditionalScreenInterface
import com.project.app.Helpers.Constants.Companion.STATUS_UPDATE_FETCH_FINISHED
import com.project.app.Interfaces.NotifyInterface
import com.project.app.Interfaces.TimeInterface
import kotlinx.coroutines.*
import java.time.Duration
import java.util.*


class MainActivity : AppCompatActivity(), AdditionalScreenInterface, SocketBase.SocketConnectionInterface {
    private lateinit var socketBase: SocketBase


    fun getSocketBase(): SocketBase {
        if (!::socketBase.isInitialized) {
            socketBase = SocketBase(this)
        }
        return socketBase


    }

    override fun onDisconnected() {
        updateStatusScreen(STATUS_DISCONNECTED)
        Log.e("DISCONNECTED", "MAIN")

    }


    override fun onConnected() {
        Log.e("onConnected Interface", "MAIN")
        updateStatusScreen(STATUS_CONNECTED)
        val adap = findViewById<ViewPager>(R.id.mainViewPager).adapter as MainViewPagerAdapter
        if (adap != null) {
            if (adap.isStreamInit()) {
                showProgress()

                (findViewById<ViewPager>(R.id.mainViewPager).adapter as MainViewPagerAdapter).streamFragment.fetchUpdatesBeforeTimestamp()
            }

        }

        getSocketBase().notifyOnNewQuestions(Date().time.toString(), object : NotifyInterface {
            override fun onNewCount(count: Int, timestamp: String) {
                GlobalScope.launch(Dispatchers.Main) {
                    updateNotyCount(count)

                }
            }

        })


    }


    override fun onStop() {
        super.onStop()
        getSocketBase().stopNotifyOnNewQuestions()
        getSocketBase().socket.disconnect()
    }

    override fun onFailed() {
        ErrorBase.socketError("11")
        updateStatusScreen(STATUS_CONNECTION_FAILED)
    }

    override fun onClose() {
        updateStatusScreen(STATUS_UPDATE_FETCH_FINISHED)
    }

    private lateinit var adapter: MainViewPagerAdapter


    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            /*  R.id.home -> {
                  changeTNV(R.id.home)
                  mainViewPager.setCurrentItem(Constants.VP_POS_HOME, true)
                  return@OnNavigationItemSelectedListener true
              }
              R.id.trending -> {
                  changeTNV(R.id.trending)
                  mainViewPager.setCurrentItem(Constants.VP_POS_TRENDING, true)

                  return@OnNavigationItemSelectedListener true
              }*/
            R.id.stream -> {
                changeTNV(R.id.stream)
                mainViewPager.setCurrentItem(Constants.VP_POS_STREAM, true)

                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }
    private val mOnPageChangeListener = object : ViewPager.OnPageChangeListener {
        override fun onPageScrollStateChanged(p0: Int) {
        }

        override fun onPageScrolled(p0: Int, p1: Float, p2: Int) {
        }

        override fun onPageSelected(p0: Int) {

            bnv.menu.getItem(p0).isChecked = true
            changeTNV(bnv.menu.getItem(p0).itemId)
            showTNV()
            showBNV()

        }

    }

    override fun onAttachFragment(fragment: android.support.v4.app.Fragment?) {
        if (fragment is StartupFragment) {
            val startupFragment = fragment
            startupFragment.setOnHeadlineSelectedListener(this)
        }
        super.onAttachFragment(fragment)

    }


    private fun changeTNV(menuItemID: Int) {
        findViewById<Toolbar>(R.id.tnv).menu.clear()
        findViewById<Toolbar>(R.id.tnv).setOnMenuItemClickListener(object : Toolbar.OnMenuItemClickListener {
            override fun onMenuItemClick(it: MenuItem?): Boolean {
                if (it != null) {
                    when (it.itemId) {
                        R.id.add -> {
                            Log.e("onLcikc", "Casd")
                            val questionCreateDialogFragment: QuestionCreateDialogFragment =
                                QuestionCreateDialogFragment()
                            questionCreateDialogFragment.setParent(this@MainActivity)
                            questionCreateDialogFragment.show(supportFragmentManager, "creator")
                            setIndicatorBlue()
                            /*   getSocketBase().sendQuestionToServer(object : SocketBase.QuestionInterface {
                                   override fun onSent() {
                                       setIndicatorGreen()
                                   }

                                   override fun onFailed() {
                                       setIndicatorRed()
                                   }
                               })*/

                        }

                    }

                }

                return true
            }
        })

        when (menuItemID) {

            R.id.home -> {
         //       findViewById<Toolbar>(R.id.tnv).inflateMenu(R.menu.tnv_home)
            }
            R.id.stream -> {
           //     findViewById<Toolbar>(R.id.tnv).inflateMenu(R.menu.tnv_stream)
            }
            /*    R.id.trending -> {
                    findViewById<Toolbar>(R.id.tnv).inflateMenu(R.menu.tnv_trending)
                }*/


        }
    }

    fun hideTNV() {
        tnv.visibility = View.GONE
    }

    fun hideBNV() {
        bnv.visibility = View.GONE
    }

    fun showTNV() {
        tnv.visibility = View.VISIBLE
    }

    fun showBNV() {
        bnv.visibility = View.VISIBLE
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        updateStatusScreen(STATUS_STARTING)
        setUpViews()
        setUpTheme()

        changeTNV(R.id.home)
        val toolbar = findViewById<Toolbar>(R.id.tnv)




        findViewById<ImageView>(R.id.refresher_icon).setOnClickListener {
            showProgress()
            (findViewById<ViewPager>(R.id.mainViewPager).adapter as MainViewPagerAdapter).streamFragment.fetchUpdatesAfterTimestamp()

        }
        findViewById<TextView>(R.id.refresher_txt).setOnClickListener {
            showProgress()
            (findViewById<ViewPager>(R.id.mainViewPager).adapter as MainViewPagerAdapter).streamFragment.fetchUpdatesAfterTimestamp()

        }


        findViewById<View>(R.id.toolbar_more).setOnClickListener {
            optionsAnimationSmall()
            /*   if (findViewById<FrameLayout>(R.id.options).visibility == View.GONE)
                   findViewById<FrameLayout>(R.id.options).visibility = View.VISIBLE
               else
                   findViewById<FrameLayout>(R.id.options).visibility = View.GONE
   */
        }

        supportFragmentManager.beginTransaction().replace(R.id.options, TagFragment()).commit()

        findViewById<FloatingActionButton>(R.id.fab).setOnClickListener {
            val questionCreateDialogFragment =
                QuestionCreateDialogFragment()
            questionCreateDialogFragment.setParent(this@MainActivity)
            questionCreateDialogFragment.show(supportFragmentManager, "creator")
        }
        /*
        findViewById<LinearLayout>(R.id.update).setOnClickListener {
            (findViewById<ViewPager>(R.id.mainViewPager).adapter as MainViewPagerAdapter).streamFragment.fetchUpdatesAfterTimestamp()
            val group = findViewById<Group>(R.id.group2)
            group.visibility = View.GONE
        }
        findViewById<ImageView>(R.id.tag_icon).setOnClickListener {
            val group = findViewById<Group>(R.id.group)
            if (group.visibility == View.GONE) {
                group.visibility = View.VISIBLE

            } else {
                group.visibility = View.GONE
            }
        }*/


    }

     fun showProgress() {
            GlobalScope.launch(Dispatchers.Main) {        findViewById<ProgressBar>(R.id.progress_tnv).visibility=View.VISIBLE}
    }
    fun hideProgress() {
        GlobalScope.launch(Dispatchers.Main) { findViewById<ProgressBar>(R.id.progress_tnv).visibility=View.GONE}
    }
    fun updateNotyCount(nr: Int) {

        findViewById<TextView>(R.id.refresher_txt).text = nr.toString()

        val icon = findViewById<ImageView>(R.id.refresher_icon)
        val clockanim = ValueAnimator()
        clockanim.setObjectValues(0, 360)
        clockanim.addUpdateListener { anim ->
            icon.rotation = (anim.animatedValue as Int).toFloat()

        }

        clockanim.duration = 300
        clockanim.startDelay = 0
        clockanim.start()
    }

    override fun onStart() {
        super.onStart()

        startConnecting()


    }

    private fun setIndicatorRed() {
        if (tnv.findViewById<ImageView>(R.id.indicator) != null) {
            tnv.findViewById<ImageView>(R.id.indicator).setImageResource(R.drawable.indicator_red)
        }

    }

    private fun setUpViews() {
        bnv.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)
        adapter = MainViewPagerAdapter(supportFragmentManager)
        mainViewPager.adapter = adapter
        mainViewPager.addOnPageChangeListener(mOnPageChangeListener)
    }

    private fun startConnecting() {
        if (InternetBase.isConnected(this)) {

            if (checkForID()) {
                getSocketBase().connectAsync()

            } else {
                ErrorBase.idError("test")
                updateStatusScreen(STATUS_ID_FAILED)

            }


        } else {
            updateStatusScreen(STATUS_INTERNET_FAILED)
        }

    }


    fun optionsAnimationSmall() {
        val large = findViewById<FrameLayout>(R.id.options)
        val toolbar = findViewById<Toolbar>(R.id.tnv)
        val refresher_icon = findViewById<ImageView>(R.id.refresher_icon)
        val refresher_text = findViewById<TextView>(R.id.refresher_txt)
        val more_icon = findViewById<ImageView>(R.id.toolbar_more)

        val refresher = findViewById<View>(R.id.refresher)

        val duration = 200L
        if (large.visibility == View.VISIBLE) {
            large.visibility = View.GONE

            val bright = resources.getColor(R.color.white, null)
            val dark = resources.getColor(R.color.fullview_color_dark, null)

       /*     colorAnimation(bright, dark, duration, ValueAnimator.AnimatorUpdateListener { animator ->
                val color = animator.animatedValue as Int
                refresher_icon.setColorFilter(color)
                refresher_text.setTextColor(color)
                more_icon.setColorFilter(color)

            })
            refresher.setBackgroundResource(R.drawable.background_toolbar)

            colorAnimation(dark, bright, duration, ValueAnimator.AnimatorUpdateListener { animator ->
                val color = animator.animatedValue as Int

                toolbar.setBackgroundColor(color)
                window.statusBarColor = color


            })
*/

        } else {
            //Animate
            large.visibility = View.VISIBLE

        /*    val bright = resources.getColor(R.color.white, null)
            val dark = resources.getColor(R.color.fullview_color_dark, null)

            refresher.setBackgroundResource(R.drawable.background_toolbar_light)

            colorAnimation(
                resources.getColor(R.color.text_color_dark, null),
                bright,
                duration,
                ValueAnimator.AnimatorUpdateListener { animator ->
                    val color = animator.animatedValue as Int
                    refresher_icon.setColorFilter(color)
                    refresher_text.setTextColor(color)
                    more_icon.setColorFilter(color)


                })


            colorAnimation(bright, dark, duration, ValueAnimator.AnimatorUpdateListener { animator ->
                val color = animator.animatedValue as Int

                toolbar.setBackgroundColor(color)
                window.statusBarColor = color


            })*/

        }

    }


    fun colorAnimation(from: Int, to: Int, duration: Long, callback: ValueAnimator.AnimatorUpdateListener) {
        val colorAnimation: ValueAnimator = ValueAnimator.ofObject(ArgbEvaluator(), from, to)
        colorAnimation.addUpdateListener(callback)
        colorAnimation.duration = duration
        colorAnimation.start()
    }


    override fun onBackPressed() {

        if (findViewById<FrameLayout>(R.id.options).visibility == View.VISIBLE) {
            optionsAnimationSmall()
            return
        }


        /*  val group = findViewById<Group>(R.id.group)
          if (group.visibility == View.VISIBLE) {
              group.visibility = View.GONE
              return
          }
          val group2 = findViewById<Group>(R.id.group2)
          if (group2.visibility == View.VISIBLE) {
              group2.visibility = View.GONE
              return
          }
  */


        super.onBackPressed()
    }

    private fun checkForID(): Boolean {
        return true
    }


    private fun setUpTheme() {
        DesignBase.setNavigationBarColor(window)
        DesignBase.setStatusBarColor(window)
        changeTNV(R.id.home)

    }


    private fun updateStatusScreen(state: String) {

        when (state) {
            STATUS_STARTING -> {
                additionalLayer.visibility = View.VISIBLE
                supportFragmentManager.beginTransaction()
                    .replace(R.id.additionalLayer, StartupFragment(), "add")
                    .commitAllowingStateLoss()
                setIndicatorRed()
            }
            STATUS_CONNECTED -> {
                setIndicatorGreen()
                //  (mainViewPager.adapter as MainViewPagerAdapter).streamFragment.
            }
            STATUS_DISCONNECTED -> {
                setIndicatorRed()
            }
            STATUS_UPDATE_FETCH_FINISHED -> {
                supportFragmentManager.beginTransaction()
                    .remove(supportFragmentManager.findFragmentByTag("add")!!)
                    .commit()
                additionalLayer.visibility = View.GONE

            }

        }


    }

    private fun setIndicatorGreen() {
        tnv.findViewById<ImageView>(R.id.indicator).setImageResource(R.drawable.indicator_green)
    }

    private fun setIndicatorBlue() {
        tnv.findViewById<ImageView>(R.id.indicator).setImageResource(R.drawable.indicator_blue)
    }

    fun startError() {
    }
}
