package com.project.app.Fragments

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.support.v4.app.DialogFragment
import android.widget.TextView
import android.os.Bundle
import android.view.ViewGroup
import android.view.LayoutInflater
import android.view.View
import com.project.app.Objects.Question
import com.project.app.R
import android.view.Window.FEATURE_NO_TITLE
import android.app.Dialog
import android.content.DialogInterface
import android.content.res.ColorStateList
import android.graphics.Color
import android.support.constraint.motion.MotionLayout
import android.support.v4.widget.ImageViewCompat
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.util.TypedValue

import android.widget.ImageView
import android.widget.ViewFlipper
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.ValueFormatter
import com.project.app.Adapters.TagOverviewAdapter
import com.project.app.Helpers.DesignBase
import com.project.app.Interfaces.UpdateListener
import com.project.app.Interfaces.QuestionChangeListener
import com.project.app.Objects.Update
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList


class QuestionFullDialogFragment : DialogFragment() {
    val DURATION_TXTANIM = 1000.0
    val DURATION_TXTDELAY = 500.0
    val DURATION_PIEANIM = 500.0
    val DURATION_LINEANIM = 500.0
    lateinit var questionSwitchFragment: QuestionSwitchFragment
    lateinit var motionLayout: MotionLayout

    lateinit var tags: RecyclerView
    //  lateinit var add3: TextView

    lateinit var head: TextView
    lateinit var left: TextView
    lateinit var right: TextView
    lateinit var context: TextView

    val interval = 100f;

/*    lateinit var sub1: TextView
    lateinit var sub2: TextView
    lateinit var sub3: TextView*/

    // lateinit var recyc: RecyclerView

    /*  lateinit var im1: ImageView
      lateinit var im2: ImageView
      lateinit var im3: ImageView*/
    lateinit var flag: ImageView
    lateinit var share: ImageView

    lateinit var pie: PieChart
    lateinit var line: LineChart

    lateinit var pie_a1: TextView
    lateinit var pie_a2: TextView
    lateinit var pie_full: TextView

    lateinit var sw1: ImageView
    lateinit var sw2: ImageView
    lateinit var sw3: ImageView


    // lateinit var toolbar: Toolbar

    lateinit var flipper: ViewFlipper
    lateinit var temp_question: Question;
    var once = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val v = inflater.inflate(R.layout.fragment_fullview, container, false)







        tags = v.findViewById<RecyclerView>(R.id.full_add2)
        tags.layoutManager=LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL,false)
        tags.setHasFixedSize(true)
        //add3 = v.findViewById<TextView>(R.id.full_add3)
        // recyc = v.findViewById<RecyclerView>(R.id.full_recycler)

        motionLayout = v.findViewById(R.id.fullview_master)
        // sub1 = v.findViewById<TextView>(R.id.full_im_sub1)
        //sub2 = v.findViewById<TextView>(R.id.full_im_sub2)
        //sub3 = v.findViewById<TextView>(R.id.full_im_sub3)
        head = v.findViewById<TextView>(R.id.full_head)
        left = v.findViewById<TextView>(R.id.full_left)
        right = v.findViewById<TextView>(R.id.full_right)
        pie_a1 = v.findViewById<TextView>(R.id.full_pie_a1)
        pie_a2 = v.findViewById<TextView>(R.id.full_pie_a2)
        pie_full = v.findViewById<TextView>(R.id.full_pie_all)

        context = v.findViewById(R.id.full_context)
        flag = v.findViewById(R.id.full_flag)
        share = v.findViewById(R.id.full_share)
        //     im1 = v.findViewById<ImageView>(R.id.full_im1)
        //    im2 = v.findViewById<ImageView>(R.id.full_im2)
        //   im3 = v.findViewById<ImageView>(R.id.full_im3)
        line = v.findViewById(R.id.full_line)
        pie = v.findViewById<PieChart>(R.id.full_pie)
        flipper = v.findViewById(R.id.full_flipper)
        sw1 = v.findViewById(R.id.full_sw1)
        sw2 = v.findViewById(R.id.full_sw2)
        sw3 = v.findViewById(R.id.full_sw3)


        v.findViewById<ImageView>(R.id.full_back).setOnClickListener {
            dismiss()
        }

        /*  recyc.layoutManager = LinearLayoutManager(context)
          recyc.setHasFixedSize(true)
          recyc.adapter = TagAdapter()
  */
        /* toolbar = v.findViewById(R.id.full_topbar)

         toolbar.inflateMenu(R.menu.fullview)
         toolbar.setNavigationOnClickListener {
             dismiss()
         }*/
        if (once) {
            setQuestion(temp_question)
        }

        left.setOnClickListener {
            if (::questionSwitchFragment.isInitialized) {
                questionSwitchFragment.questionAnswered(0, question = temp_question)
            }
        }
        right.setOnClickListener {
            if (::questionSwitchFragment.isInitialized) {
                questionSwitchFragment.questionAnswered(1, question = temp_question)
            }
        }
        flag.setOnClickListener {
            setSlideAnimation(flag)
            flagQuestion()
        }

        share.setOnClickListener {
            setSlideAnimation(share)
            shareQuestion()
        }

        setToogles()


        return v
    }

    private fun setToogles() {


        var px: Int = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            3f, resources.displayMetrics
        ).toInt()

        val cb = resources.getColor(R.color.fullview_color, null)
        val white = resources.getColor(R.color.white, null)

        sw1.setOnClickListener {
            flipper.displayedChild = 0
            sw1.setBackgroundResource(R.drawable.circle_white)
            ImageViewCompat.setImageTintList(sw1, ColorStateList.valueOf(cb))
            ImageViewCompat.setImageTintList(sw2, ColorStateList.valueOf(white))
            ImageViewCompat.setImageTintList(sw3, ColorStateList.valueOf(white))

            sw1.setPadding(px, px, px, px)
            loadPieAnimations()

            sw2.setPadding(0, 0, 0, 0)
            sw3.setPadding(0, 0, 0, 0)
            sw2.setBackgroundResource(0)
            sw3.setBackgroundResource(0)

        }

        sw2.setOnClickListener {
            flipper.displayedChild = 1

            sw2.setBackgroundResource(R.drawable.circle_white)
            ImageViewCompat.setImageTintList(sw2, ColorStateList.valueOf(cb))
            ImageViewCompat.setImageTintList(sw1, ColorStateList.valueOf(white))
            ImageViewCompat.setImageTintList(sw3, ColorStateList.valueOf(white))
            sw2.setPadding(px, px, px, px)
            sw1.setPadding(0, 0, 0, 0)
            sw3.setPadding(0, 0, 0, 0)
            sw1.setBackgroundResource(0)
            sw3.setBackgroundResource(0)
        }

        sw3.setOnClickListener {
            flipper.displayedChild = 2
            loadLineAnimations()

            sw3.setBackgroundResource(R.drawable.circle_white)
            ImageViewCompat.setImageTintList(sw3, ColorStateList.valueOf(cb))
            ImageViewCompat.setImageTintList(sw2, ColorStateList.valueOf(white))
            ImageViewCompat.setImageTintList(sw1, ColorStateList.valueOf(white))
            sw3.setPadding(px, px, px, px)
            sw1.setPadding(0, 0, 0, 0)
            sw2.setPadding(0, 0, 0, 0)
            sw1.setBackgroundResource(0)
            sw2.setBackgroundResource(0)
        }
    }

    private fun shareQuestion() {
    }

    private fun setSlideAnimation(flag: ImageView?) {
        val o = ObjectAnimator.ofFloat(flag, "translationX", -30f).apply {
            duration = 100
        }
        val pause = ObjectAnimator.ofFloat(flag, "translationX", -30f).apply {
            duration = 200
        }
        val o1 = ObjectAnimator.ofFloat(flag, "translationX", 0f).apply {
            duration = 100
        }
        val set = AnimatorSet()
        set.playSequentially(o, pause, o1)
        set.start()
    }


    private fun flagQuestion() {
        Log.e("FLAG QUESTION", "ID: " + temp_question._id)
    }

    fun setQuestion(q: Question) {
        this.temp_question = q
        if (!::head.isInitialized) {
            once = true
            temp_question = q
            return
        }
        head.text = q.text
        left.text = q.answers[0]
        right.text = q.answers[1]
        context.text = q.context
        loadCharts(q)
     //   setStatusTimer(q.updated)
        /*  sub1.text = (q.votes[0] + q.votes[1]).toString()
        sub2.text = q.votes[0].toString()
        sub3.text = q.votes[1].toString()*/

       tags.adapter=TagOverviewAdapter(ArrayList(q.tags.toList()))

        questionSwitchFragment.addUpdatesToQuestion(q, object : QuestionChangeListener {
            override fun onUpdate(timestamp: String, question: List<Question>) {
                if (isVisible) {
                    Log.e("QuestionUpdate", "FRAGMENT_: " + q._id+"   ")
                   // setQuestion(question[0]
                    temp_question=question[0]
                    updatePieChart(question[0])
                }
            }

            override fun onError(er: String) {

            }
        }, object: UpdateListener{
            override fun onUpdatesReady(content: ArrayList<Update>, timest: Long) {
                Log.e("HistoryUpdate", "FRAGMENT_: " + q._id+"   ")
                updateLineChart(content[0])
            }

            override fun onFailed() {

            }
        })



    }



    override fun onDismiss(dialog: DialogInterface?) {
        super.onDismiss(dialog)

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.FullScreenDialogStyle)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        val dialog = super.onCreateDialog(savedInstanceState)
        dialog.window?.requestFeature(FEATURE_NO_TITLE)





        return dialog
    }

    override fun onStart() {
        super.onStart()
        val dialog = dialog
        if (dialog != null) {
            dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
    }

    private fun loadCharts(question: Question) {
        loadPieChart(question)
        loadLineChart(question)

        /* var barList: ArrayList<BarEntry> = ArrayList()

         var question: Question = content[p1]


         val bar_a1: BarChart = p0.card.findViewById(R.id.bar_a1)
         val bar_a2: BarChart = p0.card.findViewById(R.id.bar_a2)


         val entryList_a1: ArrayList<BarEntry> = ArrayList()
         val entryList_a2: ArrayList<BarEntry> = ArrayList()

         val barEntry_a1: BarEntry = BarEntry(1.0F, question.votes[0].toFloat())
         val barEntry_a2: BarEntry = BarEntry(1.0F, question.votes[1].toFloat())

         bar_a1.axisLeft.axisMaximum = (question.votes[0].toFloat() + question.votes[1].toFloat())
         bar_a1.axisRight.axisMaximum = (question.votes[0].toFloat() + question.votes[1].toFloat())
         bar_a2.axisLeft.axisMaximum = (question.votes[0].toFloat() + question.votes[1].toFloat())
         bar_a2.axisRight.axisMaximum = (question.votes[0].toFloat() + question.votes[1].toFloat())



         entryList_a1.add(barEntry_a1)
         entryList_a2.add(barEntry_a2)

         val dataSet_a1: BarDataSet = BarDataSet(entryList_a1, null)
         val dataSet_a2: BarDataSet = BarDataSet(entryList_a2, null)

         DesignBase.styleChartData(DesignBase.BAR_QUESTION_TEXT2, dataSet_a1)
         DesignBase.styleChartData(DesignBase.BAR_QUESTION_TEXT2, dataSet_a2)

         DesignBase.removeChartLabels(bar_a1)
         DesignBase.removeChartLabels(bar_a2)

         bar_a1.data = BarData(dataSet_a1)
         bar_a1.invalidate()

         bar_a2.data = BarData(dataSet_a2)
         bar_a2.invalidate()

         bar_a1.animate()
         bar_a2.animate()
   */

        /*   pie.setHoleColor(Color.TRANSPARENT)

           DesignBase.removeChartLabels(pie)
           val entryList_pie: ArrayList<PieEntry> = ArrayList()
           entryList_pie.add(PieEntry(question.votes[0].toFloat()))
           entryList_pie.add(PieEntry(question.votes[1].toFloat()))

           val pieDataSet: PieDataSet = PieDataSet(entryList_pie, null)
           pieDataSet.setDrawValues(true)
           pieDataSet.setColors(
               context.resources.getColor(R.color.chart_pie_a1, null),
              context.resources.getColor(R.color.chart_pie_a2, null)
           )

           pie.data = PieData(pieDataSet)
           pie.invalidate()
           pie.animate()

     */
    }

    fun updateLineChart(update:Update){
        Log.e("ULC","A: 1")

        val now = Date().time
        val moshi = Moshi.Builder().build()
        var adapter: JsonAdapter<Array<Int>> = moshi.adapter(Array<Int>::class.java)
        val votes: Array<Int> = adapter.fromJson(update.payload)!!
        val xFormatted = -(now - update.timestamp.toLong()).toFloat()

        val lds1:LineDataSet = line.lineData.dataSets[0] as LineDataSet
        var maxY1=-1f
       if(lds1.values.size!=0) maxY1= lds1.getEntryForIndex(lds1.values.size-1).y
        if (votes[0] > maxY1) {
            if (lds1.values.size != 0) {
                var prevQ = lds1.values[lds1.values.size - 1]
                if (xFormatted in (prevQ.x - interval)..(prevQ.x + interval)) {
                    //IN RANGE-> UPDATE PREVIOUS DATAPOINT
                    Log.e("ULC","A: 0"+xFormatted+"  "+votes[0])

                    prevQ.y = votes[0].toFloat()
                } else {
                    Log.e("ULC","A: 1"+xFormatted+"  "+votes[0])

                    lds1.addEntry(Entry(xFormatted, votes[0].toFloat(), update.timestamp))

                }
            } else {
                Log.e("ULC","A: 3"+xFormatted+"  "+votes[0])

                lds1.addEntry(Entry(xFormatted, votes[0].toFloat(), update.timestamp))

            }
        }


        val lds2:LineDataSet = line.lineData.dataSets[1] as LineDataSet
        var maxY2=-1f
        if(lds2.values.size!=0) maxY2= lds2.getEntryForIndex(lds2.values.size-1).y
        if (votes[1] > maxY2) {
            if (lds2.values.size != 0) {
                var prevQ = lds2.values[lds2.values.size - 1]
                if (xFormatted in (prevQ.x - interval)..(prevQ.x + interval)) {
                    //IN RANGE-> UPDATE PREVIOUS DATAPOINT
                    prevQ.y = votes[1].toFloat()
                } else {
                    lds2.addEntry(Entry(xFormatted, votes[1].toFloat(), update.timestamp))

                }
            } else {
                lds2.addEntry(Entry(xFormatted, votes[1].toFloat(), update.timestamp))

            }
        }
        line.data=LineData(lds1,lds2)

        /*lds1.notifyDataSetChanged()
        line.notifyDataSetChanged()
        line.animateX(DURATION_LINEANIM.toInt())
        line.animateY(DURATION_LINEANIM.toInt())*/
        line.invalidate()

    }


    private fun loadLineChart(question: Question) {
        DesignBase.removeChartLabels(line)

        val scale = 1f
        questionSwitchFragment.activity.getSocketBase().getUpdates(question._id, object : UpdateListener {
            override fun onUpdatesReady(content: ArrayList<Update>, times: Long) {
                GlobalScope.launch() {
                    if (isAdded) {
                        val now = Date().time
                        Log.e("updates ready: ", "DATA: " + content.size)
                        var entries1: ArrayList<Entry> = ArrayList()
                        var entries2: ArrayList<Entry> = ArrayList()

                        val moshi = Moshi.Builder().build()
                        var adapter: JsonAdapter<Array<Int>> = moshi.adapter(Array<Int>::class.java)


                        //SORT LIST FROM SERVER BY TS
                        content.sortBy { it.timestamp.toLong() }
                        //CREATE VALUES

                        var maxY1 = -1
                        var maxY2 = -1




                        for (update in content) {
                            //  val update=content[j]
                            val votes: Array<Int> = adapter.fromJson(update.payload)!!


                            val xFormatted = -(now - update.timestamp.toLong()).toFloat() * scale

                            if (votes[0] > maxY1) {
                                if (entries1.size != 0) {
                                    var prevQ = entries1[entries1.size - 1]
                                    if (xFormatted in (prevQ.x - interval)..(prevQ.x + interval)) {
                                        //IN RANGE-> UPDATE PREVIOUS DATAPOINT
                                        prevQ.y = votes[0].toFloat()
                                    } else {
                                        entries1.add(Entry(xFormatted, votes[0].toFloat(), update.timestamp))
                                        //NOT IN RANGE-> NEW DATA POINT
                                    }
                                } else {
                                    entries1.add(Entry(xFormatted, votes[0].toFloat(), update.timestamp))

                                }




                                maxY1 = votes[0]


                            }

                            if (votes[1] > maxY2) {
                                if (entries2.size != 0) {
                                    var prevQ = entries2[entries2.size - 1]
                                    if (xFormatted in (prevQ.x - interval)..(prevQ.x + interval)) {
                                        //IN RANGE-> UPDATE PREVIOUS DATAPOINT
                                        prevQ.y = votes[1].toFloat()
                                    } else {
                                        entries2.add(Entry(xFormatted, votes[1].toFloat(), update.timestamp))
                                        //NOT IN RANGE-> NEW DATA POINT
                                    }
                                } else {
                                    entries2.add(Entry(xFormatted, votes[1].toFloat(), update.timestamp))

                                }




                                maxY2 = votes[1]


                            }
                            Log.d(
                                "DEBUG UPDATEs",
                                "DATA: +   " + entries1.size + "    " + entries2.size + "   " + content.size
                            )
                        }


                        val dataSet_a1 = LineDataSet(entries1, null)
                        val dataSet_a2 = LineDataSet(entries2, null)

                        DesignBase.setUpLineDataSet(dataSet_a1, resources.getColor(R.color.color_a1, null))
                        DesignBase.setUpLineDataSet(dataSet_a2, resources.getColor(R.color.color_a2, null))


                        line.data = LineData(dataSet_a1, dataSet_a2)
                        line.xAxis.isEnabled = true
                        line.axisRight.isEnabled = false
                        line.xAxis.valueFormatter = object : ValueFormatter() {


                            override fun getFormattedValue(value: Float): String {
                                val pl = dataSet_a1.getEntryForXValue(value, 0f).data.toString()
                                return getDate(pl.toLong(), "dd/MM")
                            }
                        }
                        line.invalidate()

                    }
                }
            }

            override fun onFailed() {
            }
        })


    }

    fun getDate(milliSeconds: Long, dateFormat: String): String {
        //dd/MM/yyyy hh:mm:ss
        val formatter = SimpleDateFormat(dateFormat)
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = milliSeconds
        return formatter.format(calendar.time)
    }

    private fun loadPieChart(question: Question) {
        val allvotes: Float = (question.votes[0] + question.votes[1]).toFloat()



        pie.setHoleColor(Color.TRANSPARENT)
        pie.holeRadius = 50f * 1.3f
        pie.setTransparentCircleAlpha(0)
        DesignBase.removeChartLabels(pie)
        val entryList_pie: ArrayList<PieEntry> = ArrayList()
        entryList_pie.add(PieEntry(question.votes[0].toFloat()))
        entryList_pie.add(PieEntry(question.votes[1].toFloat()))

        val pieDataSet = PieDataSet(entryList_pie, null)

        DesignBase.setUpPieDataSet(pieDataSet,getContext())



        pie.centerText = "TEXT"
        pie.data = PieData(pieDataSet)

        loadPieAnimations()

        if (question.votes[0] < question.votes[1]) {
            Log.e(
                "TT",
                "TT: " + ((100 * question.votes[0] / allvotes) * 3.6f) / 2f + "  " + (question.votes[0] / allvotes)
            )
            pie.rotation = -(90f + ((100 * question.votes[0].toFloat() / allvotes.toFloat()) * 3.6f) / 2f)
        } else {
            Log.e(
                "TT222",
                "TT: " + ((100 * question.votes[1] / allvotes) * 3.6f) / 2f + "  " + (question.votes[0] / allvotes)
            )
            //1559671073227
            //1559670980131
            //   pie.rotation = (90f - ((100 * question.votes[1].toFloat() / allvotes.toFloat()) * 3.6f) / 2f)
            //pie.rotation = ((100 * question.votes[1].toFloat() / allvotes.toFloat()) * 3.6f) / 2f)        }

        }
    }

    private fun updatePieChart(question: Question) {
        val allvotes: Float = (question.votes[0] + question.votes[1]).toFloat()
        val entryList_pie: ArrayList<PieEntry> = ArrayList()
        entryList_pie.add(PieEntry(question.votes[0].toFloat()))
        entryList_pie.add(PieEntry(question.votes[1].toFloat()))

        val pieDataSet = PieDataSet(entryList_pie, null)

        if (question.votes[0] < question.votes[1]) {

            pie.rotation = -(90f + ((100 * question.votes[0].toFloat() / allvotes.toFloat()) * 3.6f) / 2f)
        } else {
            pie.rotation = (90f - ((100 * question.votes[1].toFloat() / allvotes.toFloat()) * 3.6f) / 2f)

        }
        DesignBase.setUpPieDataSet(pieDataSet,getContext())
        pie.data = PieData(pieDataSet)
        loadPieAnimations()



    }










    private fun loadPieAnimations() {
        val allvotes: Float = (temp_question.votes[0] + temp_question.votes[1]).toFloat()

        pie.animateXY(DURATION_PIEANIM.toInt(), DURATION_PIEANIM.toInt())


        val txtanimator = ValueAnimator()
        txtanimator.setObjectValues(0, (100 * temp_question.votes[0] / allvotes).toInt())
        txtanimator.addUpdateListener { anim ->
            pie_a1.text = " " + anim.animatedValue + "% "
        }

        txtanimator.duration = (DURATION_TXTANIM.toLong() * (temp_question.votes[0] / allvotes)).toLong()
        txtanimator.startDelay = DURATION_TXTDELAY.toLong()
        txtanimator.start()

        val txtanimator2 = ValueAnimator()
        txtanimator2.setObjectValues(0, (100 * temp_question.votes[1] / allvotes).toInt())
        txtanimator2.addUpdateListener { anim ->
            pie_a2.text = " " + anim.animatedValue + "% "
        }

        txtanimator2.duration = DURATION_TXTANIM.toLong()
        txtanimator2.startDelay = DURATION_TXTDELAY.toLong()
        txtanimator2.start()

        val txtanimator3 = ValueAnimator()
        txtanimator3.setObjectValues(0, (allvotes).toInt())
        txtanimator3.addUpdateListener { anim ->
            var s: Int = anim.animatedValue as Int
            when {
                s > 999 -> {
                    //4 Stellen
                    s = (s / 1000f).toInt()
                    pie_full.text = "" + s + "K"

                }
            }
            pie_full.text = s.toString()

        }

        txtanimator3.duration = DURATION_TXTANIM.toLong()
        txtanimator3.startDelay = DURATION_TXTDELAY.toLong()
        txtanimator3.start()


    }
    private fun loadLineAnimations() {
        line.animateXY(DURATION_LINEANIM.toInt(), DURATION_LINEANIM.toInt())
    }

    fun setParent(questionSwitchFragment: QuestionSwitchFragment) {
        this.questionSwitchFragment = questionSwitchFragment
    }
}


