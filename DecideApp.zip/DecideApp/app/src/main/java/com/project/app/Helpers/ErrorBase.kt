package com.project.app.Helpers

class ErrorBase {
    companion object {
        fun idError(debugMessage : String) {
            println("[DEBUG] $debugMessage")
        }

        fun socketError(s: String) {

        }
    }
}