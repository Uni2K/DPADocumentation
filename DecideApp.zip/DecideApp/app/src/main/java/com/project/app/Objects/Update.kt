package com.project.app.Objects

import android.support.v7.util.DiffUtil


open class Update : Comparable<Update> {

    override fun compareTo(other: Update): Int {
        return 10

    }

    private var _id: String = "-1"
    var questionid: String = "-1"
    var userid: String = "-1"
    var timestamp: String = "-1"
    var payload :String="-1"
    var voteon:Int=-1


    constructor(_id: String, questionid: String, userid: String, timestamp: String, payload: String,voteon:Int) {
        this._id = _id
        this.questionid = questionid
        this.userid = userid
        this.timestamp = timestamp
        this.payload = payload
        this.voteon=voteon
    }
}